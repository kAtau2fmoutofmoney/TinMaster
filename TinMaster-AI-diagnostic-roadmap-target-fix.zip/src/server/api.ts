import express from 'express';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import mammoth from 'mammoth';
import { requireSupabaseRole, requireSupabaseUser } from './supabaseAuth';
import { rateLimitGemini } from './rateLimit';
import {
  classifyGeminiError,
  generateWithGeminiResilience,
  GeminiResilienceError,
  GeminiResponseError,
  getRetryAfterMs,
  parseAndValidateExtractedQuestions,
} from './geminiResilience';

dotenv.config();

let aiClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

class GeminiApiCallError extends Error {
  readonly status?: number;
  readonly retryAfterMs?: number;

  constructor(error: unknown, retryAfterMs?: number) {
    super(error instanceof Error ? error.message : 'Gemini API request failed.', { cause: error });
    this.name = 'GeminiApiCallError';
    const status = (error as { status?: unknown } | null)?.status;
    this.status = typeof status === 'number' ? status : undefined;
    this.retryAfterMs = retryAfterMs;
  }
}

function readPositiveEnvNumber(name: string, fallback: number, maximum: number): number {
  const configured = Number(process.env[name]);
  if (!Number.isFinite(configured) || configured <= 0) return fallback;
  return Math.min(Math.floor(configured), maximum);
}

function logExtractionAttempt(details: {
  model: string;
  category: string;
  retryCount: number;
  durationMs: number;
}): void {
  console.info(
    '[gemini-extraction]',
    JSON.stringify({
      model: details.model,
      errorCategory: details.category,
      retryCount: details.retryCount,
      processingDurationMs: details.durationMs,
    })
  );
}

function getExtractionErrorMessage(error: unknown): string {
  if (error instanceof GeminiResilienceError) {
    if (error.category === 'quota_exhausted') {
      return 'Gemini đã hết hạn mức sử dụng của dự án. Vui lòng kiểm tra quota/billing rồi thử lại.';
    }
    if (error.category === 'cancelled') {
      return 'Yêu cầu trích xuất đã bị hủy. Vui lòng thử lại.';
    }
    if (error.category === 'deadline_exceeded') {
      return 'Gemini xử lý quá lâu. Tệp vẫn được giữ lại; vui lòng thử lại sau.';
    }
    if (
      !error.fallbackConfigured &&
      ['overloaded', 'rate_limited', 'timeout', 'network'].includes(error.category)
    ) {
      return 'Gemini đang tạm thời không khả dụng và chưa cấu hình mô hình dự phòng. Tệp vẫn được giữ lại; vui lòng thử lại sau.';
    }
    if (error.category === 'rate_limited') {
      return 'Gemini đang nhận quá nhiều yêu cầu. Vui lòng đợi một chút rồi thử lại.';
    }
    if (error.category === 'overloaded' || error.category === 'network') {
      return 'Gemini đang tạm thời không khả dụng. Tệp vẫn được giữ lại; vui lòng thử lại sau.';
    }
    if (error.category === 'timeout') {
      return 'Gemini xử lý quá lâu. Tệp vẫn được giữ lại; vui lòng thử lại sau.';
    }
  }
  if (error instanceof GeminiResponseError) {
    return 'Gemini trả về dữ liệu câu hỏi không hợp lệ. Vui lòng thử lại hoặc dùng tệp rõ hơn.';
  }
  return 'Không thể xử lý tệp này. Vui lòng thử lại hoặc kiểm tra định dạng tệp.';
}

export const app = express();

app.use(express.json({ limit: process.env.VERCEL ? '4mb' : '50mb' }));
app.use(express.urlencoded({ extended: true, limit: process.env.VERCEL ? '4mb' : '50mb' }));

function registerApiRoutes() {
  // API 1: Health check
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      service: 'TinMaster Adaptive Learning Platform',
      version: '1.0.0',
      geminiConfigured: !!process.env.GEMINI_API_KEY,
    });
  });

  // API 2: AI Pedagogical Explanation
  app.post(
    '/api/ai/explain',
    requireSupabaseUser,
    rateLimitGemini('/api/ai/explain'),
    async (req, res) => {
    try {
      const { question, userAnswer, conceptName, studentScore } = req.body;
      const ai = getGenAI();

      if (!ai) {
        return res.json({
          explanation: question?.explanation || 'Không có giải thích chi tiết.',
          misconceptionDiagnosis: `Khái niệm "${conceptName}" cần lưu ý bẫy đề thi và các quy tắc cú pháp cơ bản.`,
          studyTips: [
            'Xem kỹ lại định nghĩa trong SGK Kết nối tri thức',
            'Thực hành lại câu hỏi tương tự trong 48 giờ tới',
          ],
          }
        );
      }

      const prompt = `Bạn là chuyên gia sư phạm Tin học luyện thi tốt nghiệp THPT tại Việt Nam.
Hãy phân tích câu hỏi sau cho học sinh (Điểm năng lực hiện tại: ${studentScore * 10}/10):
Chuyên đề: ${conceptName}
Đề bài: ${question.stem}
Đoạn mã (nếu có): ${question.codeSnippet?.code || 'Không có'}
Đáp án chuẩn của câu hỏi: ${question.explanation}
Lựa chọn / câu trả lời của học sinh: ${JSON.stringify(userAnswer)}

Yêu cầu trả về định dạng JSON thuần túy (không dùng markdown code blocks) có cấu trúc:
{
  "explanation": "Giải thích chi tiết ngắn gọn, dễ hiểu, logic từng bước",
  "misconceptionDiagnosis": "Chẩn đoán nguyên nhân học sinh chọn sai (nhầm lẫn khái niệm, sai cú pháp, bẫy biên hay cẩu thả)",
  "studyTips": ["Mẹo 1", "Mẹo 2", "Mẹo 3"]
}`;

      let text = '';
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
          },
        });
        text = response.text?.trim() || '{}';
      } catch (firstErr: any) {
        console.warn('First model attempt failed for explain, retrying with gemini-3.5-flash:', firstErr?.message);
        const retryResponse = await ai.models.generateContent({
          model: 'gemini-3.5-flash',
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
          },
        });
        text = retryResponse.text?.trim() || '{}';
      }
      const parsed = JSON.parse(text);
      res.json(parsed);
    } catch (err: any) {
      console.warn('AI explain error fallback:', err?.message);
      res.json({
        explanation: req.body.question?.explanation || 'Giải thích chuẩn theo SGK GDPT 2018.',
        misconceptionDiagnosis: 'Lưu ý các từ khóa mang tính phủ định hoặc điều kiện ràng buộc trong đề thi.',
        studyTips: [
          'Đọc kỹ đề và vẽ nháp sơ đồ luồng dữ liệu trước khi chọn phương án',
          'Ôn lại định nghĩa cốt lõi trong SGK Tin học 11/12 Kết nối tri thức',
        ],
      });
    }
  });

  // API 3: AI Video Lesson Script Generator
  app.post(
    '/api/ai/video-script',
    requireSupabaseUser,
    rateLimitGemini('/api/ai/video-script'),
    async (req, res) => {
    try {
      const { conceptId, conceptName, topicName } = req.body;
      const ai = getGenAI();

      if (!ai) {
        return res.status(400).json({ error: 'Gemini API not configured' });
      }

      const prompt = `Bạn là đạo diễn bài giảng video giáo dục số ngắn (Micro-learning 3 phút) cho học sinh THPT chuẩn bị thi Tốt nghiệp môn Tin học.
Hãy biên soạn kịch bản video cho khái niệm: "${conceptName}" (Chủ đề: ${topicName}).
Trả về định dạng JSON thuần túy:
{
  "conceptId": "${conceptId}",
  "conceptName": "${conceptName}",
  "targetDurationMinutes": 3,
  "learningObjective": "Mục tiêu bài học ngắn gọn",
  "scenes": [
    {
      "sceneNumber": 1,
      "durationSeconds": 25,
      "title": "Tên phân cảnh",
      "visualDescription": "Mô tả hình ảnh đồ họa trực quan trên màn hình",
      "codeSnippet": "Mã lệnh code nếu có",
      "narrationVoiceover": "Lời thoại thuyết minh truyền cảm, tập trung bẫy đề thi",
      "keyHighlight": "Ý chính nổi bật hiển thị trên màn hình"
    }
  ],
  "miniQuiz": {
    "questionText": "Câu hỏi kiểm tra nhanh sau video",
    "options": ["Lựa chọn A", "Lựa chọn B", "Lựa chọn C", "Lựa chọn D"],
    "correctIndex": 1,
    "explanation": "Giải thích ngắn vì sao đúng"
  }
}`;

      let responseText = '';
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
          },
          }
        );
        responseText = response.text?.trim() || '';
      } catch (firstErr: any) {
        // If 503 UNAVAILABLE (high demand), retry with alternative fast model gemini-3.5-flash
        console.warn('First model attempt failed, retrying with fallback model:', firstErr?.message);
        const retryResponse = await ai.models.generateContent({
          model: 'gemini-3.5-flash',
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
          },
        });
        responseText = retryResponse.text?.trim() || '';
      }

      if (!responseText) {
        throw new Error('Empty response from AI model');
      }

      res.json(JSON.parse(responseText));
    } catch (err: any) {
      console.warn('AI video-script fallback applied:', err?.message);
      // Return high-quality pedagogical fallback storyboard instead of 500
      const { conceptId = 'C01', conceptName = 'Khái niệm Tin học', topicName = 'Chuyên đề' } = req.body || {};
      res.json({
        conceptId,
        conceptName,
        targetDurationMinutes: 3,
        learningObjective: `Nắm vững bản chất cốt lõi của ${conceptName}, xử lý gọn các câu hỏi mức độ Vận dụng trong Đề thi Tốt nghiệp THPT Tin học.`,
        scenes: [
          {
            sceneNumber: 1,
            durationSeconds: 25,
            title: 'Phân cảnh 1: Đặt vấn đề & Tình huống thực tế',
            visualDescription: `Hiển thị slide hoạt họa sinh động: Tình huống phát sinh bài toán trong môi trường thực tiễn liên quan đến ${topicName}.`,
            narrationVoiceover: `Chào các bạn học sinh 2k7! Trong cấu trúc đề thi tốt nghiệp THPT môn Tin học, phần ${conceptName} thường là điểm phân hóa điểm 8+. Hôm nay chúng ta sẽ cùng giải mã bản chất trong đúng 3 phút.`,
            keyHighlight: `Trọng tâm đề thi: ${conceptName}`,
          },
          {
            sceneNumber: 2,
            durationSeconds: 45,
            title: 'Phân cảnh 2: Mổ xẻ Bản chất & Cơ chế hoạt động',
            visualDescription: `Sơ đồ khối trực quan động và minh họa từng bước xử lý dữ liệu của ${conceptName}.`,
            narrationVoiceover: `Để không bị mất điểm oan, hãy nhớ: Bản chất của ${conceptName} xoay quanh luồng dữ liệu vào, điều kiện dừng và các giá trị biên.`,
            keyHighlight: 'Hiểu bản chất thay vì học vẹt công thức',
          },
          {
            sceneNumber: 3,
            durationSeconds: 50,
            title: 'Phân cảnh 3: Bẫy đề thi THPT Bộ GD&ĐT thường gặp',
            visualDescription: 'Bảng đối chiếu 2 đoạn code/lệnh: Một bên là cách tư duy trực giác sai lầm, một bên là chuẩn mực giải thuật.',
            narrationVoiceover: `Điểm bẫy phổ biến nhất: Đề thi thường thay đổi một toán tử quan hệ hoặc biến chỉ số. 42% thí sinh trong đợt khảo sát đã bỏ qua điều kiện biên này!`,
            keyHighlight: 'Bẫy đề thi: Chú ý điều kiện biên và kiểu dữ liệu',
          },
          {
            sceneNumber: 4,
            durationSeconds: 30,
            title: 'Phân cảnh 4: Công thức giải nhanh & Tóm tắt',
            visualDescription: 'Mindmap tổng hợp 3 nguyên tắc vàng cần kiểm tra trước khi tô đáp án.',
            narrationVoiceover: `Tóm lại, gặp dạng bài ${conceptName}: Bước 1 kiểm tra điều kiện, Bước 2 tính toán nháp từng bước, Bước 3 loại trừ phương án sai.`,
            keyHighlight: '3 Bước tư duy chuẩn xác',
          },
        ],
        miniQuiz: {
          questionText: `Trong chuyên đề ${conceptName}, yếu tố quan trọng nhất cần kiểm tra kỹ trước khi chọn phương án trả lời là gì?`,
          options: [
            'Điều kiện biên và kiểu dữ liệu đầu vào của bài toán',
            'Độ dài của đoạn mã chương trình',
            'Tên biến đặt theo tiếng Anh hay tiếng Việt',
            'Thứ tự các câu hỏi trước đó trong đề',
          ],
          correctIndex: 0,
          explanation: 'Điều kiện biên và sự tương thích kiểu dữ liệu là nguyên nhân dẫn đến hơn 60% lỗi sai trong các câu hỏi vận dụng Tin học.',
        },
      });
    }
  });

  // API 4: Extract Questions from File (.docx, .pdf, .jpg, .jpeg, .png)
  app.post(
    '/api/exercises/extract-file',
    requireSupabaseUser,
    requireSupabaseRole(['teacher', 'admin']),
    rateLimitGemini('/api/exercises/extract-file'),
    async (req, res) => {
    const { file, answerKeyFile } = req.body;

    if (!file || !file.name || !file.base64) {
      return res.status(400).json({
        success: false,
        error: 'Dữ liệu file không hợp lệ hoặc thiếu thông tin.',
        }
      );
    }

    const fileName = file.name;
    const fileExt = fileName.substring(fileName.lastIndexOf('.')).toLowerCase();
    const cleanBase64 = file.base64.includes('base64,')
      ? file.base64.split('base64,')[1]
      : file.base64;
    const processingStartedAt = Date.now();
    const extractionDeadlineMs = readPositiveEnvNumber(
      'GEMINI_EXTRACTION_DEADLINE_MS',
      180_000,
      240_000
    );
    const requestAbortController = new AbortController();
    const onRequestAborted = () => requestAbortController.abort();
    const onResponseClosed = () => {
      if (!res.writableEnded) requestAbortController.abort();
    };
    req.once('aborted', onRequestAborted);
    res.once('close', onResponseClosed);

    try {
      let docxExtractedText = '';
      let answerKeyExtractedText = '';

      // 1. If docx: extract text directly using mammoth (no OCR required)
      if (fileExt === '.docx') {
        const fileBuffer = Buffer.from(cleanBase64, 'base64');
        const result = await mammoth.extractRawText({ buffer: fileBuffer });
        docxExtractedText = result.value || '';
      }

      // If answer key is docx: extract text
      if (answerKeyFile && answerKeyFile.base64) {
        const keyExt = (answerKeyFile.name || '').substring((answerKeyFile.name || '').lastIndexOf('.')).toLowerCase();
        const cleanKeyBase64 = answerKeyFile.base64.includes('base64,')
          ? answerKeyFile.base64.split('base64,')[1]
          : answerKeyFile.base64;

        if (keyExt === '.docx') {
          const keyBuffer = Buffer.from(cleanKeyBase64, 'base64');
          const keyResult = await mammoth.extractRawText({ buffer: keyBuffer });
          answerKeyExtractedText = keyResult.value || '';
        }
      }

      // 2. Build AI Request for Gemini
      const curriculumPrompt = `Bạn là chuyên gia số hóa đề thi môn Tin học THPT chương trình GDPT 2018 của Bộ Giáo dục & Đào tạo Việt Nam.
Hãy đọc kỹ nội dung đề thi, nhận diện chính xác tiếng Việt có dấu, công thức toán học, đoạn code (Python, SQL, HTML, CSS), và các phương án A, B, C, D.

Quy định cấu trúc hóa:
1. Phân loại loại câu hỏi (questionType):
   - "single_choice": Câu trắc nghiệm 4 lựa chọn A, B, C, D (Phần I). Cần có mảng singleChoiceOptions gồm 4 phần tử { label: 'A'|'B'|'C'|'D', text: string, isCorrect: boolean }.
   - "true_false_multistatement": Câu hỏi Đúng/Sai (Phần II). Gồm 4 phát biểu con a, b, c, d với mảng trueFalseStatements gồm 4 phần tử { subOrder: 'a'|'b'|'c'|'d', statementText: string, isCorrect: boolean }.
2. Gợi ý chủ đề (topicId) phù hợp:
   - "AI_FUNDAMENTALS" (Trí tuệ nhân tạo, Học máy)
   - "WEB_DEVELOPMENT" (HTML5, CSS3, Thiết kế Web)
   - "RELATIONAL_DATABASE" (CSDL Quan hệ, Khóa)
   - "SQL_QUERIES" (Truy vấn dữ liệu SQL)
   - "PYTHON_PROGRAMMING" (Lập trình Python, Giải thuật)
   - "COMPUTER_NETWORK" (Mạng máy tính, Internet, Giao thức)
   - "CYBER_SECURITY" (An toàn thông tin, Đạo đức số)
3. Độ khó (difficulty): "easy" (Dễ), "medium" (Vừa), "hard" (Khó).
4. Cấp độ tư duy (cognitiveLevel): "knowledge", "comprehension", "application", "high_application".
5. Đối chiếu đáp án (Answer Key Matching):
   ${
     answerKeyExtractedText
       ? `Nội dung bảng đáp án kèm theo:\n"""\n${answerKeyExtractedText}\n"""\nHãy đối chiếu thứ tự câu hỏi trong đề thi với bảng đáp án này để đánh dấu isCorrect chính xác.`
       : 'Không có file đáp án riêng. Hãy tìm xem trong đề có đáp án in đậm, gạch chân hoặc ghi chú đáp án hay không.'
   }
   - Nếu tìm thấy đáp án đúng rõ ràng: đặt confidence: "high", needsReview: false.
   - Nếu KHÔNG chắc chắn hoặc KHÔNG tìm thấy đáp án đúng: đặt confidence: "low", needsReview: true, reviewReason: "Chưa có đáp án chắc chắn, cần giáo viên rà soát và chọn phương án đúng."

Yêu cầu trả về mảng JSON thuần túy (không bọc code block markdown):
[
  {
    "stem": "Nội dung câu hỏi...",
    "questionType": "single_choice",
    "codeSnippet": { "language": "python", "code": "..." },
    "singleChoiceOptions": [
      { "label": "A", "text": "Nội dung A", "isCorrect": false },
      { "label": "B", "text": "Nội dung B", "isCorrect": true },
      { "label": "C", "text": "Nội dung C", "isCorrect": false },
      { "label": "D", "text": "Nội dung D", "isCorrect": false }
    ],
    "trueFalseStatements": [
      { "subOrder": "a", "statementText": "Phát biểu a", "isCorrect": true },
      { "subOrder": "b", "statementText": "Phát biểu b", "isCorrect": false },
      { "subOrder": "c", "statementText": "Phát biểu c", "isCorrect": true },
      { "subOrder": "d", "statementText": "Phát biểu d", "isCorrect": false }
    ],
    "topicId": "AI_FUNDAMENTALS",
    "difficulty": "medium",
    "cognitiveLevel": "comprehension",
    "explanation": "Giải thích chi tiết lời giải...",
    "confidence": "high",
    "needsReview": false,
    "reviewReason": ""
  }
]`;

      let extractedQuestions: any[] = [];

      if (process.env.GEMINI_API_KEY) {
        let contentsPayload: any;

        if (fileExt === '.docx') {
          // Pure text-based prompt
          contentsPayload = `${curriculumPrompt}\n\nNỘI DUNG VĂN BẢN TRÍCH XUẤT TỪ FILE ĐỀ THI (${fileName}):\n"""\n${docxExtractedText}\n"""`;
        } else if (fileExt === '.pdf') {
          // Multimodal PDF (handles text and scanned OCR)
          const parts: any[] = [
            {
              inlineData: {
                mimeType: 'application/pdf',
                data: cleanBase64,
              },
            },
            {
              text: `${curriculumPrompt}\n\nHãy đọc toàn bộ tài liệu PDF trên (${fileName}) và trích xuất danh sách câu hỏi.`,
            },
          ];

          // If answer key is attached as PDF or image
          if (answerKeyFile && answerKeyFile.base64 && !answerKeyExtractedText) {
            const keyClean = answerKeyFile.base64.includes('base64,')
              ? answerKeyFile.base64.split('base64,')[1]
              : answerKeyFile.base64;
            const keyMime = answerKeyFile.mimeType || (answerKeyFile.name?.endsWith('.pdf') ? 'application/pdf' : 'image/png');
            parts.push({
              inlineData: {
                mimeType: keyMime,
                data: keyClean,
              },
            });
            parts.push({
              text: 'Tài liệu bổ sung đính kèm ở trên là BẢNG ĐÁP ÁN. Hãy đối chiếu số thứ tự câu hỏi để điền đáp án đúng.',
            });
          }

          contentsPayload = { parts };
        } else {
          // Multimodal Image (JPG / PNG OCR)
          const mimeType = file.mimeType || (fileExt === '.png' ? 'image/png' : 'image/jpeg');
          const parts: any[] = [
            {
              inlineData: {
                mimeType,
                data: cleanBase64,
              },
            },
            {
              text: `${curriculumPrompt}\n\nĐây là hình ảnh chụp đề thi (${fileName}). Hãy chạy OCR nhận diện chính xác từng câu hỏi, công thức, mã code và phương án.`,
            },
          ];

          if (answerKeyFile && answerKeyFile.base64 && !answerKeyExtractedText) {
            const keyClean = answerKeyFile.base64.includes('base64,')
              ? answerKeyFile.base64.split('base64,')[1]
              : answerKeyFile.base64;
            const keyMime = answerKeyFile.mimeType || (answerKeyFile.name?.endsWith('.pdf') ? 'application/pdf' : 'image/png');
            parts.push({
              inlineData: {
                mimeType: keyMime,
                data: keyClean,
              },
            });
            parts.push({
              text: 'Tài liệu bổ sung đính kèm ở trên là BẢNG ĐÁP ÁN. Hãy đối chiếu số thứ tự câu hỏi để điền đáp án đúng.',
            });
          }

          contentsPayload = { parts };
        }

        let modelUsed = process.env.GEMINI_PRIMARY_MODEL?.trim() || 'gemini-3.8-flash';
        let retryCount = 0;
        let processingDurationMs = 0;
        try {
          const generated = await generateWithGeminiResilience(
            async (model, attempt) => {
              const requestMetadata: { retryAfterMs?: number } = {};
              const gemini = new GoogleGenAI({
                apiKey: process.env.GEMINI_API_KEY,
                httpOptions: {
                  timeout: attempt.timeoutMs,
                  retryOptions: { attempts: 1 },
                  headers: { 'User-Agent': 'aistudio-build' },
                  fetch: async (input, init) => {
                    const controller = new AbortController();
                    const abortSignals = [attempt.signal, init?.signal].filter(
                      (signal): signal is AbortSignal => signal != null
                    );
                    const abortHandlers = abortSignals.map((signal) => {
                      const abort = () => controller.abort(signal.reason);
                      if (signal.aborted) abort();
                      else signal.addEventListener('abort', abort, { once: true });
                      return { signal, abort };
                    });

                    try {
                      const response = await globalThis.fetch(input, {
                        ...init,
                        signal: controller.signal,
                      });
                      requestMetadata.retryAfterMs = getRetryAfterMs(
                        response.headers.get('Retry-After')
                      );
                      return response;
                    } finally {
                      abortHandlers.forEach(({ signal, abort }) =>
                        signal.removeEventListener('abort', abort)
                      );
                    }
                  },
                },
              });

              try {
                return await gemini.models.generateContent({
                  model,
                  contents: contentsPayload,
                  config: {
                    responseMimeType: 'application/json',
                  },
                });
              } catch (error) {
                throw new GeminiApiCallError(error, requestMetadata.retryAfterMs);
              }
            },
            {
              primaryModel: process.env.GEMINI_PRIMARY_MODEL?.trim() || 'gemini-3.8-flash',
              fallbackModel: process.env.GEMINI_FALLBACK_MODEL?.trim() || undefined,
              maxRetries: 2,
              perAttemptTimeoutMs: readPositiveEnvNumber(
                'GEMINI_ATTEMPT_TIMEOUT_MS',
                30_000,
                60_000
              ),
              overallDeadlineMs: extractionDeadlineMs - (Date.now() - processingStartedAt),
              responseReserveMs: 15_000,
              signal: requestAbortController.signal,
            }
          );

          modelUsed = generated.model;
          retryCount = generated.retryCount;
          const jsonText = generated.value.text?.trim() || '';
          extractedQuestions = parseAndValidateExtractedQuestions(jsonText);
          processingDurationMs = Date.now() - processingStartedAt;
          logExtractionAttempt({
            model: modelUsed,
            category: 'none',
            retryCount,
            durationMs: processingDurationMs,
          });
        } catch (error) {
          const category =
            error instanceof GeminiResilienceError
              ? error.category
              : error instanceof GeminiResponseError
                ? error.category
                : classifyGeminiError(error);
          const details =
            error instanceof GeminiResilienceError
              ? {
                  model: error.model,
                  retryCount: error.retryCount,
                  durationMs: Math.max(
                    error.durationMs,
                    Date.now() - processingStartedAt
                  ),
                }
              : {
                  model: modelUsed,
                  retryCount,
                  durationMs: Math.max(
                    processingDurationMs,
                    Date.now() - processingStartedAt
                  ),
                };

          logExtractionAttempt({ ...details, category });

          if (!(error instanceof GeminiResponseError)) {
            throw error;
          }
        }
      }

      // If AI produced questions, format and return them
      if (extractedQuestions.length > 0) {
        const batchRandom = Math.random().toString(36).substring(2, 7);
        const formattedQuestions = extractedQuestions.map((q, idx) => {
          const id = `Q_IMP_${Date.now()}_${batchRandom}_${idx + 1}`;
          const isSingle = q.questionType === 'single_choice' || !q.trueFalseStatements;

          return {
            id,
            questionType: isSingle ? 'single_choice' : 'true_false_multistatement',
            stem: q.stem || `Câu hỏi trích xuất #${idx + 1}`,
            codeSnippet: q.codeSnippet && q.codeSnippet.code ? q.codeSnippet : undefined,
            singleChoiceOptions: isSingle
              ? (q.singleChoiceOptions && q.singleChoiceOptions.length === 4
                  ? q.singleChoiceOptions
                  : [
                      { label: 'A', text: q.singleChoiceOptions?.[0]?.text || 'Lựa chọn A', isCorrect: !!q.singleChoiceOptions?.[0]?.isCorrect },
                      { label: 'B', text: q.singleChoiceOptions?.[1]?.text || 'Lựa chọn B', isCorrect: !!q.singleChoiceOptions?.[1]?.isCorrect },
                      { label: 'C', text: q.singleChoiceOptions?.[2]?.text || 'Lựa chọn C', isCorrect: !!q.singleChoiceOptions?.[2]?.isCorrect },
                      { label: 'D', text: q.singleChoiceOptions?.[3]?.text || 'Lựa chọn D', isCorrect: !!q.singleChoiceOptions?.[3]?.isCorrect },
                    ])
              : undefined,
            trueFalseStatements: !isSingle
              ? (q.trueFalseStatements && q.trueFalseStatements.length === 4
                  ? q.trueFalseStatements
                  : [
                      { subOrder: 'a', statementText: q.trueFalseStatements?.[0]?.statementText || 'Phát biểu a', isCorrect: !!q.trueFalseStatements?.[0]?.isCorrect, explanation: '' },
                      { subOrder: 'b', statementText: q.trueFalseStatements?.[1]?.statementText || 'Phát biểu b', isCorrect: !!q.trueFalseStatements?.[1]?.isCorrect, explanation: '' },
                      { subOrder: 'c', statementText: q.trueFalseStatements?.[2]?.statementText || 'Phát biểu c', isCorrect: !!q.trueFalseStatements?.[2]?.isCorrect, explanation: '' },
                      { subOrder: 'd', statementText: q.trueFalseStatements?.[3]?.statementText || 'Phát biểu d', isCorrect: !!q.trueFalseStatements?.[3]?.isCorrect, explanation: '' },
                    ])
              : undefined,
            conceptId: q.conceptId || 'CS12_AI_CONCEPTS',
            topicId: q.topicId || 'AI_FUNDAMENTALS',
            grade: q.grade || 12,
            strand: q.strand || 'CS',
            cognitiveLevel: q.cognitiveLevel || 'comprehension',
            difficulty: q.difficulty || 'medium',
            estimatedTimeSec: 45,
            competencyCode: q.competencyCode || 'NLa',
            explanation: q.explanation || 'Lời giải chi tiết chuẩn chương trình Tin học GDPT 2018.',
            keyTakeaway: q.keyTakeaway || 'Kiến thức cốt lõi ôn thi THPT.',
            source: `Tải lên từ file: ${fileName}`,
            sourceYear: 2025,
            isVerified: true,
            // Meta attributes for review screen
            confidence: q.confidence || (q.needsReview ? 'low' : 'high'),
            needsReview: typeof q.needsReview === 'boolean' ? q.needsReview : (q.confidence === 'low'),
            reviewReason: q.reviewReason || (q.needsReview ? 'Cần kiểm tra lại đáp án' : ''),
            sourceFile: fileName,
          };
        });

        return res.json({
          success: true,
          fileName,
          questions: formattedQuestions,
          count: formattedQuestions.length,
        });
      }

      // 3. Fallback Heuristic Parser if AI is unavailable or couldn't parse
      if (docxExtractedText) {
        const fallbackQuestions = parseQuestionsFromDocxText(docxExtractedText, fileName);
        if (fallbackQuestions.length > 0) {
          return res.json({
            success: true,
            fileName,
            questions: fallbackQuestions,
            count: fallbackQuestions.length,
            note: 'Trích xuất bằng bộ phân tích văn bản DOCX trực tiếp.',
          });
        }
      }

      // If nothing could be extracted from this file
      return res.json({
        success: false,
        fileName,
        error: 'Không thể đọc nội dung câu hỏi từ file này, vui lòng kiểm tra lại định dạng hoặc nhập thủ công.',
      });
    } catch (err: unknown) {
      if (requestAbortController.signal.aborted || res.destroyed) return;
      return res.json({
        success: false,
        fileName,
        error: getExtractionErrorMessage(err),
      });
    } finally {
      req.removeListener('aborted', onRequestAborted);
      res.removeListener('close', onResponseClosed);
    }
  });

  // Helper heuristic text parser for DOCX/TXT files
  function parseQuestionsFromDocxText(text: string, fileName: string): any[] {
    const questions: any[] = [];
    // Split by "Câu 1", "Câu 2", "Câu 1.", "Câu 1:" etc.
    const blocks = text.split(/(?:^|\n)(?:Câu\s+\d+[:.]|\b\d+[\.:]\s+)/i).filter((b) => b.trim().length > 10);

    blocks.forEach((block, idx) => {
      const lines = block.split('\n').map((l) => l.trim()).filter(Boolean);
      if (lines.length === 0) return;

      const stem = lines[0];
      const optA = lines.find((l) => /^[A|a][\.:\)]/i.test(l))?.replace(/^[A|a][\.:\)]\s*/i, '') || 'Lựa chọn A';
      const optB = lines.find((l) => /^[B|b][\.:\)]/i.test(l))?.replace(/^[B|b][\.:\)]\s*/i, '') || 'Lựa chọn B';
      const optC = lines.find((l) => /^[C|c][\.:\)]/i.test(l))?.replace(/^[C|c][\.:\)]\s*/i, '') || 'Lựa chọn C';
      const optD = lines.find((l) => /^[D|d][\.:\)]/i.test(l))?.replace(/^[D|d][\.:\)]\s*/i, '') || 'Lựa chọn D';

      // Check if explanation or answer is listed
      const ansMatch = block.match(/Đáp án[:\s]+([A-D])/i);
      const correctLetter = ansMatch ? ansMatch[1].toUpperCase() : '';

      questions.push({
        id: `Q_DOCX_${Date.now()}_${Math.random().toString(36).substring(2, 7)}_${idx + 1}`,
        questionType: 'single_choice',
        stem: stem.length > 5 ? stem : `Câu hỏi trích xuất #${idx + 1} từ ${fileName}`,
        singleChoiceOptions: [
          { label: 'A', text: optA, isCorrect: correctLetter === 'A' },
          { label: 'B', text: optB, isCorrect: correctLetter === 'B' },
          { label: 'C', text: optC, isCorrect: correctLetter === 'C' },
          { label: 'D', text: optD, isCorrect: correctLetter === 'D' },
        ],
        topicId: 'PYTHON_PROGRAMMING',
        conceptId: 'CS12_AI_CONCEPTS',
        grade: 12,
        strand: 'CS',
        cognitiveLevel: 'comprehension',
        difficulty: 'medium',
        estimatedTimeSec: 45,
        competencyCode: 'NLa',
        explanation: 'Trích xuất từ file đề thi tài liệu DOCX.',
        keyTakeaway: 'Nội dung ôn luyện Tin học THPT.',
        source: `File DOCX: ${fileName}`,
        sourceYear: 2025,
        isVerified: true,
        confidence: correctLetter ? 'high' : 'low',
        needsReview: !correctLetter,
        reviewReason: correctLetter ? '' : 'Chưa có đáp án chắc chắn, cần giáo viên rà soát chọn đáp án đúng.',
        sourceFile: fileName,
      });
    });

    return questions;
  }
}

registerApiRoutes();
export default app;
