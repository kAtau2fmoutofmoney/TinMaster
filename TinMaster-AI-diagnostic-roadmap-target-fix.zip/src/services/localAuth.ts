import type { AuthProfile } from './authService';
import type { UserRole } from '../types';

const USERS_KEY = 'tinmaster_local_users_v1';
const SESSION_KEY = 'tinmaster_local_session_v1';

type LocalUser = AuthProfile & { passwordHash: string };

function readUsers(): LocalUser[] {
  try {
    const raw = localStorage.getItem(USERS_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch { return []; }
}

function writeUsers(users: LocalUser[]) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

async function hashPassword(password: string): Promise<string> {
  const data = new TextEncoder().encode(password);
  const digest = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

function makeId(): string {
  if (typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  return `local_${Date.now()}_${Math.random().toString(36).slice(2)}`;
}

export function isLocalAuthEnabled(): boolean {
  return !localStorage.getItem('tinmaster_force_supabase_v1');
}

export async function registerLocalUser(fullName: string, email: string, password: string): Promise<AuthProfile> {
  const normalizedEmail = email.trim().toLowerCase();
  const users = readUsers();
  if (users.some((user) => user.email.toLowerCase() === normalizedEmail)) {
    throw new Error('Email này đã được đăng ký trên thiết bị này.');
  }
  const profile: AuthProfile = {
    id: makeId(),
    email: normalizedEmail,
    displayName: fullName.trim() || normalizedEmail.split('@')[0],
    role: 'student' as UserRole,
  };
  const user: LocalUser = { ...profile, passwordHash: await hashPassword(password) };
  writeUsers([...users, user]);
  return profile;
}

export async function signInLocalUser(email: string, password: string): Promise<AuthProfile> {
  const normalizedEmail = email.trim().toLowerCase();
  const user = readUsers().find((candidate) => candidate.email.toLowerCase() === normalizedEmail);
  if (!user || user.passwordHash !== await hashPassword(password)) {
    throw new Error('Email hoặc mật khẩu không chính xác.');
  }
  const { passwordHash: _passwordHash, ...profile } = user;
  localStorage.setItem(SESSION_KEY, JSON.stringify(profile));
  return profile;
}

export function getLocalSession(): AuthProfile | null {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    return raw ? JSON.parse(raw) as AuthProfile : null;
  } catch { return null; }
}

export function signOutLocalUser() {
  localStorage.removeItem(SESSION_KEY);
}
