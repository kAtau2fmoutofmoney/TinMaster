export const LEADERBOARD_EMPTY_STATE = 'Chưa có dữ liệu xếp hạng.';
