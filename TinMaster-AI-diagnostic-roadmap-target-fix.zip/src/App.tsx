import React, { useState, useEffect } from 'react';
import {
  UserProfile,
  StudentMastery,
  ExamSession,
  Question,
  AdaptiveRecommendation,
  LearningPathDay,
  ExamBlueprint,
  ExamTrack,
} from './types';
import {
  OFFICIAL_EXAM_BLUEPRINT_2025,
  CONCEPTS_LIST,
} from './data/curriculumData';
import { SAMPLE_QUESTION_BANK } from './data/questionBank';
import { AdaptiveLearningEngine } from './services/adaptiveEngine';
import {
  ExamCatalogItem,
  ExamAttemptRecord,
  ClassStudentExamResult,
  INITIAL_EXAMS_CATALOG,
} from './data/examCatalogData';

import { Header } from './components/Header';
import { StudentDashboard } from './components/StudentDashboard';
import { ExamSimulation } from './components/ExamSimulation';
import { ExamReview } from './components/ExamReview';
import { KnowledgeMap } from './components/KnowledgeMap';
import { TeacherDashboard } from './components/TeacherDashboard';
import { AIVideoLessonModal } from './components/AIVideoLessonModal';
import { GoogleWorkspaceModal } from './components/GoogleWorkspaceModal';
import { AdaptivePracticeSession } from './components/AdaptivePracticeSession';
import { PracticeBankView } from './components/PracticeBankView';
import { GoogleSignInModal } from './components/GoogleSignInModal';
import { ExamsCatalogView } from './components/ExamsCatalogView';
import { SelectTrackModal } from './components/SelectTrackModal';
import { AuthProvider, useAuth } from './auth/AuthProvider';
import { TeacherInvitationModal } from './components/TeacherInvitationModal';
import { DiagnosticAssessmentModal, type DiagnosticPreferences, type DiagnosticSubmission } from './components/DiagnosticAssessmentModal';
import { AuthenticationRoute } from './components/AuthPages';
import { MemberDirectory } from './components/MemberDirectory';
import { AccountSettingsPage, PublicMemberProfilePage } from './components/MemberPages';
import { supabase } from './services/supabaseClient';
import { createAvatarUrl, getMyMemberProfile, type MemberProfile } from './services/memberService';

import {
  Play,
  HardDrive,
  Mail,
  Sparkles,
  BookOpen,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';

const STORAGE_KEY_MASTERIES = 'tinmaster_masteries_v1';
const STORAGE_KEY_USER_STATE = 'tinmaster_user_state_v1';
const STORAGE_KEY_EXAM_HISTORY = 'tinmaster_student_exam_history_v1';
const STORAGE_KEY_QUESTION_STATS = 'tinmaster_question_stats_v1';
const STORAGE_KEY_DIAGNOSTIC = 'tinmaster_diagnostic_profile_v1';

function userStorageKey(baseKey: string, userId: string) {
  return `${baseKey}:${userId}`;
}

export default function App() {
  return (
    <AuthProvider>
      <AppRoutes />
    </AuthProvider>
  );
}

function AppRoutes() {
  const path = window.location.pathname.replace(/\/+$/, '') || '/';
  if (['/admin', '/admin/dashboard', '/admin/setup-password', '/register', '/forgot-password', '/reset-password'].includes(path)) {
    return <AuthenticationRoute />;
  }
  return <TinMasterApp />;
}

function pageFromLocation(): { tab: string; username: string | null } {
  const path = window.location.pathname.replace(/\/+$/, '') || '/';
  if (path === '/members') return { tab: 'member_directory', username: null };
  if (path.startsWith('/members/')) {
    return { tab: 'public_profile', username: decodeURIComponent(path.slice('/members/'.length)) };
  }
  if (path === '/settings') return { tab: 'account_settings', username: null };
  return { tab: 'dashboard', username: null };
}

function TinMasterApp() {
  const auth = useAuth();
  const initialPage = pageFromLocation();
  const [activeTab, setActiveTab] = useState<string>(initialPage.tab);
  const [profileTarget, setProfileTarget] = useState<string | null>(initialPage.username);
  const [memberProfile, setMemberProfile] = useState<MemberProfile | null>(null);
  const [memberAvatarUrl, setMemberAvatarUrl] = useState<string | null>(null);

  // 1. User State
  const emptyUserState: UserProfile = {
    id: '',
    name: '',
    email: '',
    role: 'student',
    estimatedScore: 0,
    completedQuestionsCount: 0,
    streakDays: 0,
    xp: 0,
    researchGroup: 'unassigned',
    totalStudyMinutes: 0,
  };

  const [userState, setUser] = useState<UserProfile>(emptyUserState);

  // 2. Knowledge Mastery State (Bayesian Knowledge Tracing)
  // IMPORTANT: this state is loaded per authenticated user below. Never use one
  // global localStorage key for all accounts.
  const [masteries, setMasteries] = useState<Record<string, StudentMastery>>({});
  const [userDataHydrated, setUserDataHydrated] = useState(false);
  const hydratedUserIdRef = React.useRef<string | null>(null);

  // 2.1 Question Bank (Preloaded + Custom uploaded / manually created)
  const [allQuestions, setAllQuestions] = useState<Question[]>(() => {
    try {
      const saved = localStorage.getItem('tinmaster_custom_questions_v1');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const seenIds = new Set<string>(SAMPLE_QUESTION_BANK.map((q) => q.id));
          const uniqueCustom: Question[] = [];
          for (const q of parsed) {
            if (q && q.id && !seenIds.has(q.id)) {
              seenIds.add(q.id);
              uniqueCustom.push(q);
            }
          }
          // Self-heal localStorage by storing clean, deduplicated array
          localStorage.setItem('tinmaster_custom_questions_v1', JSON.stringify(uniqueCustom));
          return [...SAMPLE_QUESTION_BANK, ...uniqueCustom];
        }
      }
    } catch {}
    return SAMPLE_QUESTION_BANK;
  });

  const handleAddQuestions = (newQuestions: Question[]) => {
    setAllQuestions((prev) => {
      const existingIds = new Set(prev.map((q) => q.id));
      const deduplicatedNew: Question[] = [];

      for (let i = 0; i < newQuestions.length; i++) {
        const q = newQuestions[i];
        let finalId = q.id;
        if (!finalId || existingIds.has(finalId)) {
          finalId = `Q_CUST_${Date.now()}_${Math.random().toString(36).substring(2, 7)}_${i + 1}`;
        }
        existingIds.add(finalId);
        deduplicatedNew.push({ ...q, id: finalId });
      }

      const updated = [...prev, ...deduplicatedNew];
      try {
        const existingCustom = localStorage.getItem('tinmaster_custom_questions_v1');
        const prevCustom: Question[] = existingCustom ? JSON.parse(existingCustom) : [];
        const customIds = new Set(prevCustom.map((q) => q.id));
        const newToStore = deduplicatedNew.filter((q) => !customIds.has(q.id));
        localStorage.setItem(
          'tinmaster_custom_questions_v1',
          JSON.stringify([...prevCustom, ...newToStore])
        );
      } catch {}
      return updated;
    });
    showToast(`Đã lưu thành công ${newQuestions.length} câu hỏi vào ngân hàng bài tập!`);
  };

  // 3. Navigation & Modals
  const [currentExamSession, setCurrentExamSession] = useState<ExamSession | null>(null);
  const [showVideoModal, setShowVideoModal] = useState<boolean>(false);
  const [videoConceptId, setVideoConceptId] = useState<string | undefined>(undefined);
  const [showWorkspaceModal, setShowWorkspaceModal] = useState<boolean>(false);
  const [showTeacherInvitationModal, setShowTeacherInvitationModal] = useState(false);
  const [showSelectTrackModal, setShowSelectTrackModal] = useState<boolean>(false);
  const [pendingExamStart, setPendingExamStart] = useState<{ blueprint: ExamBlueprint; examItem?: ExamCatalogItem } | null>(null);
  const [practiceQuestions, setPracticeQuestions] = useState<Question[] | null>(null);
  const [practiceRecommendation, setPracticeRecommendation] = useState<AdaptiveRecommendation | undefined>(undefined);

  // 4. Toast notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  useEffect(() => {
    if (auth.status !== 'authenticated' || !auth.error) return;
    setToastMessage(`Lỗi xác thực: ${auth.error}`);
    const timeout = window.setTimeout(() => setToastMessage(null), 4000);
    return () => window.clearTimeout(timeout);
  }, [auth.error, auth.status]);

  // Exam Catalog, History, and Session States
  const [examsCatalog, setExamsCatalog] = useState<ExamCatalogItem[]>(() => {
    try {
      const saved = localStorage.getItem('tinmaster_custom_exams_v1');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return [...INITIAL_EXAMS_CATALOG, ...parsed];
        }
      }
    } catch {}
    return INITIAL_EXAMS_CATALOG;
  });

  const [examHistory, setExamHistory] = useState<ExamAttemptRecord[]>([]);
  type QuestionStats = Record<string, { attempts: number; correct: number }>;
  const [questionStats, setQuestionStats] = useState<QuestionStats>({});
  const [diagnosticProfile, setDiagnosticProfile] = useState<{
    preferences: DiagnosticPreferences;
    completedAt: string;
    score: number;
    questionIds: string[];
  } | null>(null);
  const [showDiagnostic, setShowDiagnostic] = useState(false);

  const [classResults] = useState<ClassStudentExamResult[]>([]);
  const [activeExamBlueprint, setActiveExamBlueprint] = useState<ExamBlueprint>(OFFICIAL_EXAM_BLUEPRINT_2025);
  const [currentExamItem, setCurrentExamItem] = useState<ExamCatalogItem | undefined>(undefined);

  // Load all user-owned learning data whenever the authenticated account changes.
  // This also resets the in-memory state when signing out, preventing account A's
  // progress from being shown or written into account B.
  useEffect(() => {
    const userId = auth.status === 'authenticated' ? auth.profile?.id : null;

    if (!userId) {
      hydratedUserIdRef.current = null;
      setUser(emptyUserState);
      setMasteries({});
      setExamHistory([]);
      setQuestionStats({});
      setDiagnosticProfile(null);
      setUserDataHydrated(false);
      return;
    }

    try {
      const savedState = localStorage.getItem(userStorageKey(STORAGE_KEY_USER_STATE, userId));
      const savedMasteries = localStorage.getItem(userStorageKey(STORAGE_KEY_MASTERIES, userId));
      const savedHistory = localStorage.getItem(userStorageKey(STORAGE_KEY_EXAM_HISTORY, userId));
      const savedQuestionStats = localStorage.getItem(userStorageKey(STORAGE_KEY_QUESTION_STATS, userId));
      const savedDiagnostic = localStorage.getItem(userStorageKey(STORAGE_KEY_DIAGNOSTIC, userId));

      const parsedState = savedState ? JSON.parse(savedState) : null;
      const parsedMasteries = savedMasteries ? JSON.parse(savedMasteries) : null;
      const parsedHistory = savedHistory ? JSON.parse(savedHistory) : null;
      const parsedQuestionStats = savedQuestionStats ? JSON.parse(savedQuestionStats) : null;
      const parsedDiagnostic = savedDiagnostic ? JSON.parse(savedDiagnostic) : null;
      // Migrate accounts created by older builds: if the account has never
      // completed a question, any seeded/placeholder mastery data must not be
      // treated as real progress.
      const hasCompletedQuestions = Number(parsedState?.completedQuestionsCount ?? 0) > 0;
      const effectiveMasteries = hasCompletedQuestions && parsedMasteries && typeof parsedMasteries === 'object'
        ? parsedMasteries
        : {};

      const hasDiagnostic = parsedDiagnostic && typeof parsedDiagnostic === 'object' && parsedDiagnostic.preferences;
      setUser(parsedState && typeof parsedState === 'object' ? {
        ...emptyUserState,
        ...parsedState,
        // A target is only valid if this student explicitly set it or
        // completed the diagnostic assessment. Never inherit the profile
        // default from older Supabase schemas.
        targetScore: hasDiagnostic
          ? Number(parsedDiagnostic.preferences.targetScore)
          : (hasCompletedQuestions ? parsedState.targetScore : undefined),
        estimatedScore: hasCompletedQuestions ? Number(parsedState.estimatedScore ?? 0) : 0,
      } : {
        ...emptyUserState,
        id: userId,
        name: auth.profile?.displayName ?? '',
        email: auth.profile?.email ?? '',
        role: auth.profile?.role ?? 'student',
        // New accounts have no target until the student explicitly sets one
        // or completes the diagnostic assessment.
        targetScore: undefined,
      });
      setMasteries(effectiveMasteries);
      setExamHistory(Array.isArray(parsedHistory) ? parsedHistory : []);
      setQuestionStats(parsedQuestionStats && typeof parsedQuestionStats === 'object' ? parsedQuestionStats : {});
      setDiagnosticProfile(parsedDiagnostic && typeof parsedDiagnostic === 'object' ? parsedDiagnostic : null);
      hydratedUserIdRef.current = userId;
      setUserDataHydrated(true);
    } catch {
      setUser({
        ...emptyUserState,
        id: userId,
        name: auth.profile?.displayName ?? '',
        email: auth.profile?.email ?? '',
        role: auth.profile?.role ?? 'student',
        targetScore: undefined,
      });
      setMasteries({});
      setExamHistory([]);
      setQuestionStats({});
      setDiagnosticProfile(null);
      hydratedUserIdRef.current = userId;
      setUserDataHydrated(true);
    }
  }, [auth.status, auth.profile?.id]);

  // Persist user-owned state under that user's own key.
  useEffect(() => {
    const userId = auth.profile?.id;
    if (!userDataHydrated || !userId || hydratedUserIdRef.current !== userId) return;
    try {
      localStorage.setItem(userStorageKey(STORAGE_KEY_USER_STATE, userId), JSON.stringify(userState));
      localStorage.setItem(userStorageKey(STORAGE_KEY_MASTERIES, userId), JSON.stringify(masteries));
      localStorage.setItem(userStorageKey(STORAGE_KEY_EXAM_HISTORY, userId), JSON.stringify(examHistory));
      localStorage.setItem(userStorageKey(STORAGE_KEY_QUESTION_STATS, userId), JSON.stringify(questionStats));
      localStorage.setItem(userStorageKey(STORAGE_KEY_DIAGNOSTIC, userId), JSON.stringify(diagnosticProfile));
    } catch {}
  }, [userDataHydrated, auth.profile?.id, userState, masteries, examHistory, questionStats, diagnosticProfile]);

  useEffect(() => {
    if (auth.status !== 'authenticated' || !supabase) {
      setMemberProfile(null);
      setMemberAvatarUrl(null);
      return;
    }

    const client = supabase;
    let active = true;
    void getMyMemberProfile(client)
      .then(async (profile) => {
        const avatarUrl = await createAvatarUrl(client, profile.avatarPath);
        if (active) {
          setMemberProfile(profile);
          setMemberAvatarUrl(avatarUrl);
        }
      })
      .catch(() => {
        if (active) {
          setMemberProfile(null);
          setMemberAvatarUrl(null);
        }
      });
    return () => { active = false; };
  }, [auth.status, auth.profile?.id, auth.profile?.displayName]);

  useEffect(() => {
    const handlePopState = () => {
      const page = pageFromLocation();
      setActiveTab(page.tab);
      setProfileTarget(page.username);
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigateTo = (tab: string, username?: string | null) => {
    setActiveTab(tab);
    setProfileTarget(username ?? null);
    const path = tab === 'member_directory'
      ? '/members'
      : tab === 'account_settings'
        ? '/settings'
        : tab === 'public_profile' && username
          ? `/members/${encodeURIComponent(username)}`
          : '/';
    window.history.pushState({}, '', path);
  };

  const handleMemberProfileSaved = (profile: MemberProfile) => {
    setMemberProfile(profile);
    if (supabase) {
      void createAvatarUrl(supabase, profile.avatarPath)
        .then(setMemberAvatarUrl)
        .catch(() => setMemberAvatarUrl(null));
    }
  };

  const user: UserProfile = auth.profile
    ? {
      ...userState,
      id: auth.profile.id,
      name: memberProfile?.displayName ?? auth.profile.displayName,
      email: auth.profile.email,
      role: auth.profile.role,
      avatarUrl: memberAvatarUrl ?? auth.profile.avatarUrl,
      school: auth.profile.school,
      grade: auth.profile.grade,
      examTrack: memberProfile ? memberProfile.examTrack : auth.profile.examTrack ?? userState.examTrack,
      // Do not fall back to the Supabase profile default. The student must
      // explicitly choose a target score or complete the diagnostic test.
      targetScore: userState.targetScore,
    }
    : userState;

  // New accounts must start with no learning data. Adaptive recommendations
  // and the roadmap are only generated after the student has actually
  // completed at least one question / created mastery data.
  const hasLearningData =
    Object.keys(masteries).length > 0;

  const recommendations = hasLearningData
    ? AdaptiveLearningEngine.getAdaptiveRecommendations(masteries, allQuestions, 3)
    : [];

  const learningPath: LearningPathDay[] = diagnosticProfile
    ? AdaptiveLearningEngine.generatePersonalizedLearningPath(
        masteries,
        allQuestions,
        diagnosticProfile.preferences,
        7
      )
    : [];

  // Assemble exam questions filtered by track for elective exams
  const assembleExamQuestions = (blueprint: ExamBlueprint, examItem?: ExamCatalogItem, track?: ExamTrack): Question[] => {
    // If the exam has custom uploaded questions, use those directly
    if (examItem?.questions && examItem.questions.length > 0) {
      return examItem.questions;
    }

    const hasElective = blueprint.hasElectiveTracks;
    if (!hasElective) {
      // Non-elective exams: use all questions as-is
      return allQuestions;
    }

    // Filter mandatory questions (sectionScope === 'mandatory' or track === 'ALL')
    const mandatoryQuestions = allQuestions.filter((q) => q.sectionScope === 'mandatory');
    const mandatoryTrueFalseQuestions = allQuestions.filter(
      (q) => q.sectionScope === 'mandatory_tf'
    );

    // Filter elective questions matching student's track
    const electiveQuestions = track
      ? allQuestions.filter(
          (q) => q.sectionScope === 'elective' && q.track === track
        )
      : [];

    // Limit to blueprint counts
    const mandatoryCount = blueprint.sections.sectionI.questionCount || 24;
    const mandatoryTrueFalseCount = blueprint.sections.sectionII.questionCount || 2;
    const electiveCount = blueprint.sections.sectionIII?.electivePerStudentCount || 2;

    const shuffle = <T,>(items: T[]): T[] => {
      const shuffled = [...items];
      for (let i = shuffled.length - 1; i > 0; i -= 1) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
      }
      return shuffled;
    };

    const selectedMandatory = shuffle(mandatoryQuestions).slice(0, mandatoryCount);
    const selectedMandatoryTrueFalse = shuffle(mandatoryTrueFalseQuestions).slice(
      0,
      mandatoryTrueFalseCount
    );
    const selectedElective = shuffle(electiveQuestions).slice(0, electiveCount);

    return [...selectedMandatory, ...selectedMandatoryTrueFalse, ...selectedElective];
  };

  // Start exam from catalog or quick button
  const handleStartExam = (blueprint?: ExamBlueprint, examItem?: ExamCatalogItem) => {
    const bp = blueprint || OFFICIAL_EXAM_BLUEPRINT_2025;
    setActiveExamBlueprint(bp);
    setCurrentExamItem(examItem);

    // If exam has elective tracks, check user has selected a track
    if (bp.hasElectiveTracks && !user.examTrack) {
      setPendingExamStart({ blueprint: bp, examItem });
      setShowSelectTrackModal(true);
      return;
    }

    setActiveTab('exam_simulation');
  };

  // Handle track selection from modal
  const handleTrackSelected = (track: ExamTrack) => {
    setUser((prev) => ({ ...prev, examTrack: track }));
    setShowSelectTrackModal(false);

    // If we had a pending exam start, continue with it now
    if (pendingExamStart) {
      setActiveExamBlueprint(pendingExamStart.blueprint);
      setCurrentExamItem(pendingExamStart.examItem);
      setPendingExamStart(null);
      setActiveTab('exam_simulation');
    }
  };

  // View completed exam review
  const handleViewExamSession = (attempt: ExamAttemptRecord) => {
    if (attempt.sessionData) {
      setCurrentExamSession(attempt.sessionData);
      setActiveTab('exam_review');
    } else {
      // Synthetic readable session
      const syntheticSession: ExamSession = {
        id: attempt.id,
        blueprintId: attempt.examId,
        examTitle: attempt.examTitle,
        startedAt: attempt.dateTaken,
        submittedAt: attempt.dateTaken,
        durationSeconds: attempt.durationSeconds,
        timeRemainingSeconds: 0,
        isCompleted: true,
        totalScore: attempt.score,
        totalCorrect: attempt.correctCount,
        questionTelemetries: {},
      };
      setCurrentExamSession(syntheticSession);
      setActiveTab('exam_review');
    }
  };

  // Teacher/Admin add custom exam
  const handleAddCustomExam = (newExam: ExamCatalogItem) => {
    setExamsCatalog((prev) => {
      const updated = [newExam, ...prev];
      try {
        const existing = localStorage.getItem('tinmaster_custom_exams_v1');
        const prevCustom = existing ? JSON.parse(existing) : [];
        localStorage.setItem('tinmaster_custom_exams_v1', JSON.stringify([newExam, ...prevCustom]));
      } catch {}
      return updated;
    });
    showToast(`Đã xuất bản kỳ thi mới: ${newExam.title}`);
  };

  // Finish exam
  const handleFinishExam = (session: ExamSession) => {
    // Get the actual questions used in this exam session
    const examQuestions = assembleExamQuestions(activeExamBlueprint, currentExamItem, user.examTrack || undefined);
    const questionsInSession = examQuestions.filter((q) => session.questionTelemetries[q.id]);
    const questionsToGrade = questionsInSession.length > 0 ? questionsInSession : examQuestions;

    // Calculate score breakdown (mandatory vs elective)
    const breakdown = AdaptiveLearningEngine.calculateExamScoreBreakdown(
      questionsToGrade,
      session.questionTelemetries,
      user.examTrack || undefined
    );

    // Update session with breakdown data
    const enrichedSession: ExamSession = {
      ...session,
      totalScore: breakdown.totalScore,
      totalCorrect: breakdown.mandatoryCorrect + breakdown.electiveCorrect,
      studentTrack: user.examTrack || undefined,
      mandatoryScore: breakdown.mandatoryScore,
      mandatoryMaxScore: breakdown.mandatoryMaxScore,
      electiveScore: breakdown.electiveScore,
      electiveMaxScore: breakdown.electiveMaxScore,
    };

    // Update masteries via Bayesian Knowledge Tracing
    let updatedMasteries = { ...masteries };

    questionsToGrade.forEach((q) => {
      const tel = session.questionTelemetries[q.id];
      if (tel && tel.userAnswer !== undefined) {
        // Use correct maxPoints based on section
        const maxPts = q.questionType === 'true_false_multistatement' ? 1.0 : 0.25;
        const scoreResult = AdaptiveLearningEngine.calculateQuestionScore(q, tel.userAnswer, maxPts);

        const currentM = updatedMasteries[q.conceptId] || {
          conceptId: q.conceptId,
          masteryScore: 0.5,
          confidenceScore: 0.5,
          totalAttempts: 0,
          correctAttempts: 0,
          consecutiveSuccessStreak: 0,
          lastPracticedAt: new Date().toISOString(),
          nextSpacedReviewAt: new Date().toISOString(),
          trend: 'stable' as const,
        };

        const updatedM = AdaptiveLearningEngine.updateConceptMastery(
          currentM,
          q.conceptId,
          scoreResult.scoreRatio,
          q.difficulty,
          tel.quadrant || 'fast_correct',
          tel.activeTimeSec || 45
        );

        updatedMasteries[q.conceptId] = updatedM;
      }
    });

    setMasteries(updatedMasteries);

    setQuestionStats((prev) => {
      const next = { ...prev };
      questionsToGrade.forEach((q) => {
        const tel = session.questionTelemetries[q.id];
        if (!tel || tel.userAnswer === undefined) return;
        const maxPts = q.questionType === 'true_false_multistatement' ? 1.0 : 0.25;
        const scoreResult = AdaptiveLearningEngine.calculateQuestionScore(q, tel.userAnswer, maxPts);
        const old = next[q.id] ?? { attempts: 0, correct: 0 };
        next[q.id] = { attempts: old.attempts + 1, correct: old.correct + (scoreResult.scoreRatio >= 0.999 ? 1 : 0) };
      });
      return next;
    });
    setCurrentExamSession(enrichedSession);

    // Save attempt to student exam history
    const prevAttempt = examHistory.find((h) => h.examId === (currentExamItem?.id || 'exam-thpt-2025-std'));
    const totalQ = questionsToGrade.length;
    const totalCorrectCount = breakdown.mandatoryCorrect + breakdown.electiveCorrect;
    const accuracy = Math.round((totalCorrectCount / Math.max(totalQ, 1)) * 100);
    const trendDiff = prevAttempt ? Number((breakdown.totalScore - prevAttempt.score).toFixed(2)) : undefined;

    const newAttempt: ExamAttemptRecord = {
      id: `attempt-${Date.now()}`,
      examId: currentExamItem?.id || 'exam-thpt-2025-std',
      examTitle: currentExamItem?.title || session.examTitle || 'Phòng Thi Chuẩn Hóa Môn Tin Học (THPT 2025)',
      category: currentExamItem?.category || 'national_standard',
      dateTaken: new Date().toISOString(),
      score: Number(breakdown.totalScore.toFixed(2)),
      maxScore: 10.0,
      totalQuestions: totalQ,
      correctCount: totalCorrectCount,
      durationSeconds: session.durationSeconds,
      accuracy,
      trendDiff,
      sessionData: enrichedSession,
      studentTrack: user.examTrack || undefined,
      mandatoryScore: breakdown.mandatoryScore,
      electiveScore: breakdown.electiveScore,
    };

    setExamHistory((prev) => {
      const updated = [newAttempt, ...prev];
      try {
        localStorage.setItem(userStorageKey(STORAGE_KEY_EXAM_HISTORY, user.id), JSON.stringify(updated));
      } catch {}
      return updated;
    });

    // Update user stats
    setUser((prev) => ({
      ...prev,
      completedQuestionsCount: prev.completedQuestionsCount + totalQ,
      xp: prev.xp + 120,
    }));

    setActiveTab('exam_review');
    showToast(`Đã chấm bài thi! Bắt buộc (26 câu): ${breakdown.mandatoryScore}/${breakdown.mandatoryMaxScore}đ | Tự chọn (2 câu): ${breakdown.electiveScore}/${breakdown.electiveMaxScore}đ | Tổng: ${breakdown.totalScore}/10.0đ`);
  };

  // Start Adaptive Practice session
  const handleStartLearningDay = (day: LearningPathDay) => {
    const dayQuestions = (day.questionIds || [])
      .map((id) => allQuestions.find((q) => q.id === id))
      .filter((q): q is Question => Boolean(q));

    if (dayQuestions.length > 0) {
      setPracticeRecommendation(undefined);
      setPracticeQuestions(dayQuestions);
      return;
    }

    const conceptQuestions = allQuestions.filter((q) => q.conceptId === day.focusConceptId).slice(0, day.questionCount);
    setPracticeRecommendation(undefined);
    setPracticeQuestions(conceptQuestions.length > 0 ? conceptQuestions : allQuestions.slice(0, day.questionCount));
  };

  const handleStartAdaptivePractice = (rec?: AdaptiveRecommendation) => {
    if (rec) {
      setPracticeRecommendation(rec);
      setPracticeQuestions([rec.question]);
    } else if (recommendations[0]) {
      setPracticeRecommendation(recommendations[0]);
      setPracticeQuestions([recommendations[0].question]);
    } else {
      setPracticeQuestions(allQuestions.slice(0, 3));
    }
  };

  // Practice a single specific question from the question bank
  const handlePracticeSingleQuestion = (question: Question) => {
    const matchedRec = recommendations.find((r) => r.question.id === question.id);
    if (matchedRec) {
      setPracticeRecommendation(matchedRec);
    } else {
      setPracticeRecommendation({
        question,
        score: 0.85,
        reasons: {
          weaknessScore: 0.7,
          recencyScore: 0.6,
          difficultyFitScore: 0.8,
          importanceScore: 0.8,
          textExplanation: 'Luyện tập câu hỏi theo lựa chọn của học sinh trong ngân hàng bài tập.',
        },
      });
    }
    setPracticeQuestions([question]);
  };

  // Start Micro-quiz (3 or 5 questions)
  const handleStartMicroQuiz = (count: number) => {
    const sortedWeak = [...CONCEPTS_LIST].sort((a, b) => {
      const mA = masteries[a.id]?.masteryScore ?? 0.5;
      const mB = masteries[b.id]?.masteryScore ?? 0.5;
      return mA - mB;
    });

    const weakConceptIds = sortedWeak.slice(0, 3).map((c) => c.id);
    const selected = allQuestions.filter((q) => weakConceptIds.includes(q.conceptId)).slice(0, count);

    setPracticeQuestions(selected.length > 0 ? selected : allQuestions.slice(0, count));
    setPracticeRecommendation(undefined);
  };

  // Finish Practice session
  const handleFinishPracticeSession = (
    results: { question: Question; isCorrect: boolean; activeTimeSec: number }[]
  ) => {
    let updatedMasteries = { ...masteries };
    let correctCount = 0;

    results.forEach((r) => {
      if (r.isCorrect) correctCount++;
      const currentM = updatedMasteries[r.question.conceptId] || {
        conceptId: r.question.conceptId,
        masteryScore: 0.5,
        confidenceScore: 0.5,
        totalAttempts: 0,
        correctAttempts: 0,
        consecutiveSuccessStreak: 0,
        lastPracticedAt: new Date().toISOString(),
        nextSpacedReviewAt: new Date().toISOString(),
        trend: 'stable' as const,
      };

      const updatedM = AdaptiveLearningEngine.updateConceptMastery(
        currentM,
        r.question.conceptId,
        r.isCorrect ? 1.0 : 0.0,
        r.question.difficulty,
        r.isCorrect ? 'fast_correct' : 'slow_incorrect',
        r.activeTimeSec
      );

      updatedMasteries[r.question.conceptId] = updatedM;
    });

    setMasteries(updatedMasteries);
    setQuestionStats((prev) => {
      const next = { ...prev };
      results.forEach((r) => {
        const old = next[r.question.id] ?? { attempts: 0, correct: 0 };
        next[r.question.id] = { attempts: old.attempts + 1, correct: old.correct + (r.isCorrect ? 1 : 0) };
      });
      return next;
    });
    setPracticeQuestions(null);
    setPracticeRecommendation(undefined);

    setUser((prev) => ({
      ...prev,
      completedQuestionsCount: prev.completedQuestionsCount + results.length,
      xp: prev.xp + results.length * 15,
    }));

    showToast(`Đã hoàn thành! Đúng ${correctCount}/${results.length} câu. +${results.length * 15} XP!`);
  };

  const handleDiagnosticSubmit = (submission: DiagnosticSubmission) => {
    const selectedQuestions = submission.questionIds
      .map((id) => allQuestions.find((q) => q.id === id))
      .filter((q): q is Question => Boolean(q));

    let updatedMasteries = { ...masteries };
    let correct = 0;

    selectedQuestions.forEach((q) => {
      const answer = submission.answers[q.id];
      const correctOption = q.singleChoiceOptions?.find((o) => o.isCorrect)?.label;
      const isCorrect = answer === correctOption;
      if (isCorrect) correct += 1;

      const current = updatedMasteries[q.conceptId];
      updatedMasteries[q.conceptId] = AdaptiveLearningEngine.updateConceptMastery(
        current,
        q.conceptId,
        isCorrect ? 1 : 0,
        q.difficulty,
        isCorrect ? 'fast_correct' : 'slow_incorrect',
        q.estimatedTimeSec
      );
    });

    const score = selectedQuestions.length ? Math.round((correct / selectedQuestions.length) * 100) : 0;
    const profile = {
      preferences: submission.preferences,
      completedAt: new Date().toISOString(),
      score,
      questionIds: submission.questionIds,
    };

    setMasteries(updatedMasteries);
    setDiagnosticProfile(profile);
    setUser((prev) => ({
      ...prev,
      targetScore: submission.preferences.targetScore,
      estimatedScore: Number((5 + (score / 100) * 4.5).toFixed(1)),
    }));
    setShowDiagnostic(false);
    showToast(`Đã phân tích bài đánh giá: ${correct}/${selectedQuestions.length} câu. AI đã tạo lộ trình 7 ngày.`);
  };

  const handleSetTargetScore = () => {
    const raw = window.prompt('Đặt mục tiêu điểm THPT (0–10):', userState.targetScore?.toString() ?? '');
    if (raw === null) return;
    const value = Number(raw.replace(',', '.'));
    if (!Number.isFinite(value) || value < 0 || value > 10) {
      showToast('Mục tiêu phải là một số từ 0 đến 10.');
      return;
    }
    setUser((prev) => ({ ...prev, targetScore: Math.round(value * 10) / 10 }));
    showToast(`Đã đặt mục tiêu ${value.toFixed(1)} điểm.`);
  };

  const handleOpenVideoModal = (conceptId?: string) => {
    setVideoConceptId(conceptId);
    setShowVideoModal(true);
  };

  if (auth.status === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f8f9fa] text-sm text-slate-600">
        Đang khôi phục phiên đăng nhập…
      </div>
    );
  }

  if (auth.status !== 'authenticated' || !auth.profile) {
    return (
      <GoogleSignInModal
        isOpen
        onSignIn={auth.signInWithGoogle}
        isLoading={false}
        error={auth.error}
        errorKind={auth.errorKind}
        onRetryProfileLoad={auth.retryProfileLoad}
        onSignOut={auth.signOut}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#f8f9fa] text-[#1e293b] flex flex-col font-sans">
      {/* 1. APP HEADER */}
      <Header
        user={user}
        memberUsername={memberProfile?.username ?? undefined}
        memberAvatarUrl={memberAvatarUrl}
        onSignOut={() => void auth.signOut()}
        onRedeemTeacherInvitation={() => setShowTeacherInvitationModal(true)}
        activeTab={activeTab}
        onTabChange={(tab) => {
          if (tab === 'member_directory') navigateTo('member_directory');
          else if (tab === 'account_settings') navigateTo('account_settings');
          else if (tab === 'public_profile') {
            if (memberProfile?.username) navigateTo('public_profile', memberProfile.username);
            else navigateTo('account_settings');
          } else {
            setActiveTab(tab);
            if (['dashboard', 'adaptive_practice', 'exam_list', 'knowledge_map', 'teacher_view'].includes(tab)) {
              window.history.pushState({}, '', '/');
            }
          }
        }}
        onOpenOwnProfile={() => {
          if (memberProfile?.username) navigateTo('public_profile', memberProfile.username);
          else navigateTo('account_settings');
        }}
        onOpenAccountSettings={() => navigateTo('account_settings')}
        onOpenVideoModal={() => handleOpenVideoModal()}
        onOpenGoogleWorkspace={() => setShowWorkspaceModal(true)}
        onOpenTrackModal={() => setShowSelectTrackModal(true)}
        onSelectTrack={handleTrackSelected}
      />

      {/* 2. FLOATING TOAST NOTIFICATION */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#1a1a1a] text-white px-4 py-2.5 rounded shadow-lg flex items-center space-x-2 text-xs font-semibold border border-[#d1d5db]">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 3. MAIN WORKSPACE CONTAINER - Expanded Width (90-95% viewport on desktop) */}
      <main className="flex-1 w-full max-w-[95%] 2xl:max-w-[1850px] mx-auto px-3 sm:px-5 lg:px-7 py-6">
        {/* VIEW A: STUDENT DASHBOARD */}
        {activeTab === 'dashboard' && (
          <StudentDashboard
            user={user}
            masteries={masteries}
            recommendations={recommendations}
            learningPath={learningPath}
            onStartExam={handleStartExam}
            onStartAdaptivePractice={handleStartAdaptivePractice}
            onStartMicroQuiz={handleStartMicroQuiz}
            onOpenVideoModal={handleOpenVideoModal}
            onNavigateToKnowledgeMap={() => setActiveTab('knowledge_map')}
            onNavigateToExercises={() => setActiveTab('adaptive_practice')}
            questionStats={questionStats}
            onSetTargetScore={handleSetTargetScore}
            diagnosticProfile={diagnosticProfile}
            onOpenDiagnostic={() => setShowDiagnostic(true)}
            onStartLearningDay={handleStartLearningDay}
          />
        )}

        {/* VIEW A2: ADAPTIVE PRACTICE & QUESTION BANK */}
        {activeTab === 'adaptive_practice' && (
          <PracticeBankView
            questions={allQuestions}
            masteries={masteries}
            recommendations={recommendations}
            userRole={user.role}
            onAddQuestions={handleAddQuestions}
            onStartSingleQuestion={handlePracticeSingleQuestion}
            onStartAdaptivePractice={handleStartAdaptivePractice}
            onStartMicroQuiz={handleStartMicroQuiz}
            onOpenVideoModal={handleOpenVideoModal}
          />
        )}

        {/* VIEW B: EXAM ROOM / SIMULATION ENGINE */}
        {activeTab === 'exam_simulation' && (
          <ExamSimulation
            blueprint={activeExamBlueprint}
            questions={assembleExamQuestions(activeExamBlueprint, currentExamItem, user.examTrack || undefined)}
            studentTrack={user.examTrack || undefined}
            onSwitchTrack={handleTrackSelected}
            onFinishExam={handleFinishExam}
            onCancelExam={() => setActiveTab('exam_list')}
          />
        )}

        {/* VIEW C: EXAM REVIEW WITH BEHAVIORAL DIAGNOSTICS */}
        {activeTab === 'exam_review' && currentExamSession && (
          <ExamReview
            session={currentExamSession}
            questions={assembleExamQuestions(activeExamBlueprint, currentExamItem, currentExamSession.studentTrack || user.examTrack || undefined)}
            masteries={masteries}
            onReturnDashboard={() => setActiveTab('exam_list')}
            onPracticeConcept={(conceptId) => {
              const matched = allQuestions.filter((q) => q.conceptId === conceptId);
              setPracticeQuestions(matched.length > 0 ? matched : allQuestions.slice(0, 3));
            }}
          />
        )}

        {/* VIEW D: EXAM CATALOG & DASHBOARD */}
        {activeTab === 'exam_list' && (
          <ExamsCatalogView
            user={user}
            exams={examsCatalog}
            examHistory={examHistory}
            classResults={classResults}
            allQuestions={allQuestions}
            onStartExam={handleStartExam}
            onViewExamSession={handleViewExamSession}
            onAddCustomExam={handleAddCustomExam}
          />
        )}

        {/* VIEW E: KNOWLEDGE MAP */}
        {activeTab === 'knowledge_map' && (
          <KnowledgeMap
            masteries={masteries}
            onStartPracticeConcept={(conceptId) => {
              const matched = allQuestions.filter((q) => q.conceptId === conceptId);
              setPracticeQuestions(matched.length > 0 ? matched : allQuestions.slice(0, 3));
            }}
            onOpenVideoModal={handleOpenVideoModal}
          />
        )}

        {/* VIEW F: TEACHER DASHBOARD */}
        {activeTab === 'teacher_view' && (user.role === 'teacher' || user.role === 'admin') && (
          <TeacherDashboard
            onOpenVideoModal={() => handleOpenVideoModal()}
            onOpenGoogleWorkspace={() => setShowWorkspaceModal(true)}
          />
        )}

        {activeTab === 'member_directory' && (
          <MemberDirectory
            onOpenMember={(username) => navigateTo('public_profile', username)}
          />
        )}

        {activeTab === 'public_profile' && (
          <PublicMemberProfilePage
            username={profileTarget ?? memberProfile?.username ?? ''}
            ownProfile={memberProfile}
            onBack={() => navigateTo('member_directory')}
            onOpenSettings={() => navigateTo('account_settings')}
          />
        )}

        {activeTab === 'account_settings' && (
          <AccountSettingsPage
            email={auth.profile?.email ?? ''}
            onBack={() => navigateTo('dashboard')}
            onSaved={handleMemberProfileSaved}
          />
        )}

      </main>

      <DiagnosticAssessmentModal
        isOpen={showDiagnostic}
        questions={allQuestions}
        initialPreferences={diagnosticProfile?.preferences}
        onClose={() => setShowDiagnostic(false)}
        onSubmit={handleDiagnosticSubmit}
      />

      {/* 4. GOOGLE WORKSPACE FLOATING ACTION BAR */}
      <aside className="fixed bottom-6 left-6 z-40">
        <div className="bg-white/95 backdrop-blur-md rounded-2xl border border-slate-200 shadow-xl p-2 flex items-center space-x-2">
          <button
            onClick={() => setShowWorkspaceModal(true)}
            className="flex items-center space-x-2 px-3.5 py-2 bg-slate-900 text-white hover:bg-slate-800 text-xs font-semibold rounded-xl transition cursor-pointer"
            title="Đồng bộ Google Drive & Gửi báo cáo Gmail"
          >
            <HardDrive className="w-3.5 h-3.5 text-blue-400" />
            <span>Google Workspace</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          </button>

          <button
            onClick={() => handleOpenVideoModal()}
            className="flex items-center space-x-1.5 px-3 py-2 bg-purple-50 hover:bg-purple-100 text-purple-700 text-xs font-semibold rounded-xl transition border border-purple-200 cursor-pointer"
            title="Tạo bài giảng video AI 3 phút"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Video AI</span>
          </button>
        </div>
      </aside>

      {/* 5. MODALS */}
      {/* Video Lesson Modal */}
      {showVideoModal && (
        <AIVideoLessonModal
          initialConceptId={videoConceptId}
          onClose={() => {
            setShowVideoModal(false);
            setVideoConceptId(undefined);
          }}
        />
      )}

      {/* Google Workspace Modal (Drive & Gmail) */}
      {showWorkspaceModal && (
        <GoogleWorkspaceModal
          user={user}
          masteries={masteries}
          recentSession={currentExamSession}
          onClose={() => setShowWorkspaceModal(false)}
        />
      )}

      {/* Adaptive Practice / Micro Quiz Modal */}
      {practiceQuestions && (
        <AdaptivePracticeSession
          questions={practiceQuestions}
          initialRecommendation={practiceRecommendation}
          onFinishPractice={handleFinishPracticeSession}
          onClose={() => {
            setPracticeQuestions(null);
            setPracticeRecommendation(undefined);
          }}
        />
      )}

      {showTeacherInvitationModal && (
        <TeacherInvitationModal
          onClose={() => setShowTeacherInvitationModal(false)}
          onRedeemed={auth.refreshProfile}
        />
      )}

      {/* Select Track Modal for Elective Exams */}
      <SelectTrackModal
        isOpen={showSelectTrackModal}
        currentTrack={user.examTrack}
        onSelectTrack={handleTrackSelected}
        onClose={() => {
          setShowSelectTrackModal(false);
          setPendingExamStart(null);
        }}
      />
    </div>
  );
}
