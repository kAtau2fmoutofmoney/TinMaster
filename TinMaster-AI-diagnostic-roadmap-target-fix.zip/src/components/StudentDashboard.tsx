import React from 'react';
import {
  UserProfile,
  StudentMastery,
  AdaptiveRecommendation,
  LearningPathDay,
  Question,
  ExamTrack,
} from '../types';
import { CONCEPTS_LIST } from '../data/curriculumData';
import { LEADERBOARD_EMPTY_STATE } from '../data/leaderboard';
import { SAMPLE_QUESTION_BANK } from '../data/questionBank';
import {
  Play,
  RotateCcw,
  Sparkles,
  ArrowRight,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  BookOpen,
  Calendar,
  Trophy,
  Code2,
  Globe,
  Brain,
} from 'lucide-react';
import type { SupabaseClient } from '@supabase/supabase-js';
import { ClassroomStudentSection } from './ClassroomStudentSection';

interface StudentDashboardProps {
  user: UserProfile;
  masteries: Record<string, StudentMastery>;
  recommendations: AdaptiveRecommendation[];
  learningPath: LearningPathDay[];
  onStartExam: () => void;
  onSelectTrack?: (track: ExamTrack) => void;
  onOpenTrackModal?: () => void;
  onStartAdaptivePractice: (recommendation?: AdaptiveRecommendation) => void;
  onStartMicroQuiz: (questionCount: number) => void;
  onOpenVideoModal: (conceptId?: string) => void;
  onNavigateToKnowledgeMap: () => void;
  onNavigateToExercises?: () => void;
  questionStats: Record<string, { attempts: number; correct: number }>;
  onSetTargetScore: () => void;
  client?: SupabaseClient | null;
  diagnosticProfile?: { completedAt: string; score: number; preferences: { targetScore: number; dailyMinutes: number; daysPerWeek: number; focus: string; goalNote?: string; examDate?: string } } | null;
  onOpenDiagnostic?: () => void;
  onStartLearningDay?: (day: LearningPathDay) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  user,
  masteries,
  recommendations,
  learningPath,
  onStartExam,
  onSelectTrack,
  onOpenTrackModal,
  onStartAdaptivePractice,
  onStartMicroQuiz,
  onOpenVideoModal,
  onNavigateToKnowledgeMap,
  onNavigateToExercises,
  questionStats,
  onSetTargetScore,
  client,
  diagnosticProfile,
  onOpenDiagnostic,
  onStartLearningDay,
}) => {
  // A brand-new account has no mastery data. Do not invent a score such as
  // 7.4/10 or 50% mastery before the student has answered anything.
  const masteryValues = Object.values(masteries);
  const hasLearningData = masteryValues.length > 0;
  const avgMastery = hasLearningData
    ? masteryValues.reduce((acc, curr) => acc + curr.masteryScore, 0) / masteryValues.length
    : 0;
  const estimatedScore = hasLearningData
    ? Math.min(9.8, Math.max(0, Math.round(avgMastery * 100) / 10))
    : null;
  const progressPercent = estimatedScore === null
    ? 0
    : Math.min(100, Math.round((estimatedScore / 10.0) * 100));

  // Only show weak areas after the student has real learning data.
  const weakConcepts = hasLearningData
    ? CONCEPTS_LIST.map((concept) => ({
        concept,
        score: Math.round((masteries[concept.id]?.masteryScore ?? 0) * 100),
      }))
        .sort((a, b) => a.score - b.score)
        .slice(0, 3)
    : [];

  // Danh sách bài tập mới nhất từ ngân hàng đề mẫu
  const recentExercises: {
    id: string;
    displayId: string;
    title: string;
    acRatio: string;
    difficulty: 'easy' | 'medium' | 'hard';
    question: Question;
  }[] = [
    {
      id: 'Q_CS10_PY_01',
      displayId: '#001',
      title: 'Thuật toán tìm kiếm nhị phân trong dãy sắp thứ tự (Python)',
      acRatio: '',
      difficulty: 'easy',
      question: SAMPLE_QUESTION_BANK[5] || SAMPLE_QUESTION_BANK[0],
    },
    {
      id: 'Q_CS10_PY_02',
      displayId: '#002',
      title: 'Tối ưu hóa cấu trúc dữ liệu mảng và danh sách List',
      acRatio: '',
      difficulty: 'medium',
      question: SAMPLE_QUESTION_BANK[6] || SAMPLE_QUESTION_BANK[1],
    },
    {
      id: 'Q_CS11_NET_01',
      displayId: '#003',
      title: 'Bài tập về mô hình mạng TCP/IP & Giao thức IP',
      acRatio: '',
      difficulty: 'hard',
      question: SAMPLE_QUESTION_BANK[4] || SAMPLE_QUESTION_BANK[2],
    },
    {
      id: 'Q_CS11_DB_01',
      displayId: '#004',
      title: 'Truy vấn SQL lọc điều kiện WHERE & Khóa chính Primary Key',
      acRatio: '',
      difficulty: 'medium',
      question: SAMPLE_QUESTION_BANK[2] || SAMPLE_QUESTION_BANK[0],
    },
    {
      id: 'Q_CS12_WEB_01',
      displayId: '#005',
      title: 'Cú pháp thẻ HTML5 và mô hình định dạng CSS Box Model',
      acRatio: '',
      difficulty: 'easy',
      question: SAMPLE_QUESTION_BANK[3] || SAMPLE_QUESTION_BANK[1],
    },
  ];

  return (
    <div className="space-y-5">
      {/* AI Diagnostic / Personalized Plan entry */}
      <div className={`rounded-xl border p-4 sm:p-5 ${diagnosticProfile ? 'bg-white border-blue-100' : 'bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200'}`}>
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-white border border-blue-100 text-blue-600 flex items-center justify-center shrink-0"><Brain className="w-5 h-5" /></div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-bold text-slate-900">{diagnosticProfile ? 'Lộ trình AI cá nhân hóa' : 'Thiết lập lộ trình học của bạn'}</h2>
                <span className="text-[10px] uppercase tracking-wide font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-700">AI Adaptive</span>
              </div>
              {diagnosticProfile ? (
                <p className="text-xs sm:text-sm text-slate-600 mt-1">Bài đầu vào: <b>{diagnosticProfile.score}%</b> · {diagnosticProfile.preferences.dailyMinutes} phút/ngày · {diagnosticProfile.preferences.daysPerWeek} ngày/tuần · mục tiêu <b>{diagnosticProfile.preferences.targetScore.toFixed(1)}</b>.</p>
              ) : (
                <p className="text-xs sm:text-sm text-slate-600 mt-1">Trả lời 12 câu + cho AI biết mục tiêu và thời gian học. Hệ thống sẽ tạo nhiệm vụ cụ thể cho từng ngày.</p>
              )}
            </div>
          </div>
          <button onClick={onOpenDiagnostic} className="btn whitespace-nowrap py-2.5 px-4 cursor-pointer justify-center">
            <Brain className="w-4 h-4" />
            {diagnosticProfile ? 'Làm lại & cập nhật lộ trình' : 'Bắt đầu bài đánh giá'}
          </button>
        </div>
      </div>

      {/* Action Quickbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white px-5 py-4 border border-slate-200 rounded-lg shadow-xs">
        <div className="flex items-center space-x-2.5 flex-wrap gap-y-1">
          <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full shrink-0" />
          <span className="text-base font-semibold text-slate-900 tracking-tight">
            Luyện thi Tin học THPT 2025
          </span>
          {/* Interactive Track Switcher */}
          <div className="flex items-center space-x-1 bg-slate-100 p-0.5 rounded-lg border border-slate-200">
            <button
              type="button"
              onClick={() => onSelectTrack && onSelectTrack('CS')}
              className={`text-xs font-bold px-2.5 py-1 rounded-md transition cursor-pointer flex items-center space-x-1 ${
                user.examTrack === 'CS'
                  ? 'bg-purple-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Định hướng Khoa học máy tính (CS)"
            >
              <Code2 className="w-3 h-3" />
              <span>Khoa học máy tính (CS)</span>
            </button>
            <button
              type="button"
              onClick={() => onSelectTrack && onSelectTrack('ICT')}
              className={`text-xs font-bold px-2.5 py-1 rounded-md transition cursor-pointer flex items-center space-x-1 ${
                user.examTrack === 'ICT'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Định hướng Khoa học ứng dụng / Tin học ứng dụng (ICT)"
            >
              <Globe className="w-3 h-3" />
              <span>Khoa học ứng dụng (ICT)</span>
            </button>
          </div>
        </div>
        <div className="flex items-center gap-2.5 overflow-x-auto pb-1 sm:pb-0 w-full sm:w-auto">
          <button
            onClick={() => onStartMicroQuiz(5)}
            className="btn-secondary text-xs whitespace-nowrap py-2 px-3.5 cursor-pointer"
            title="Làm bài kiểm tra 5 phút"
          >
            <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
            <span>Micro-Quiz 5p</span>
          </button>
          <button
            onClick={() => onOpenVideoModal()}
            className="btn-secondary text-xs whitespace-nowrap py-2 px-3.5 cursor-pointer"
            title="Tạo video bài học AI 3 phút"
          >
            <Sparkles className="w-3.5 h-3.5 text-slate-500" />
            <span>Video AI</span>
          </button>
          <button
            onClick={onStartExam}
            className="btn text-xs whitespace-nowrap py-2 px-4.5 cursor-pointer"
            title="Vào phòng thi 50 phút chuẩn quy chế"
          >
            <Play className="w-3.5 h-3.5 fill-white" />
            <span>Phòng thi 50p</span>
          </button>
        </div>
      </div>

      {/* Main Grid Layout: Content (1fr) + Sidebar (380px-420px proportionally) */}
      <div className="grid grid-cols-1 xl:grid-cols-[1fr_380px] 2xl:grid-cols-[1fr_420px] lg:grid-cols-[1fr_350px] gap-6 sm:gap-7">
        {/* LEFT COLUMN: TABLES & CORE WORKFLOW */}
        <div className="space-y-6">
          {/* Lớp học của học sinh (Classroom Student Section) */}
          <ClassroomStudentSection client={client} />

          {/* Card 1: Nhiệm vụ luyện tập hôm nay */}
          <div className="panel">
            <div className="flex items-center justify-between pb-3.5 mb-3.5 border-b border-slate-200">
              <h2 className="text-[15px] font-semibold text-slate-900">
                Nhiệm vụ luyện tập hôm nay
              </h2>
              <span className="text-xs sm:text-[13px] text-slate-500">
                <span className="font-mono font-medium text-slate-700">{recommendations.length}</span> bài tập đề xuất
              </span>
            </div>

            <div className="overflow-x-auto -mx-1 sm:mx-0">
              <table className="var-table min-w-[540px]">
                <thead>
                  <tr>
                    <th style={{ width: '48%' }}>Bài tập & Gợi ý sư phạm</th>
                    <th style={{ width: '12%' }}>Độ khó</th>
                    <th style={{ width: '16%' }}>Chủ đề</th>
                    <th style={{ width: '12%' }}>Trạng thái</th>
                    <th style={{ width: '12%', textAlign: 'center' }}>Thao tác</th>
                  </tr>
                </thead>
                <tbody>
                  {recommendations.length > 0 ? (
                    recommendations.map((rec, index) => {
                      const diffClass =
                        rec.question.difficulty === 'easy'
                          ? 'badge-diff-easy'
                          : rec.question.difficulty === 'medium'
                          ? 'badge-diff-medium'
                          : 'badge-diff-hard';
                      const diffLabel =
                        rec.question.difficulty === 'easy'
                          ? 'Dễ'
                          : rec.question.difficulty === 'medium'
                          ? 'Vừa'
                          : 'Khó';
                      const status = index === 0 ? 'Chưa làm' : 'Đang thực hiện';

                      return (
                        <tr key={`${rec.question.id}-${index}`}>
                          <td>
                            <div className="font-medium text-slate-900 text-[15px] leading-relaxed">
                              {rec.question.stem}
                            </div>
                            <div className="text-[13px] text-slate-500 mt-1.5 flex items-start gap-1 leading-relaxed">
                              <span className="font-medium text-slate-700 shrink-0">Lý do:</span>{' '}
                              <span>{rec.reasons.textExplanation}</span>
                            </div>
                          </td>
                          <td>
                            <span className={diffClass}>
                              {diffLabel}
                            </span>
                          </td>
                          <td className="text-slate-600 text-[13.5px] font-medium">
                            {rec.question.topicId.replace(/_/g, ' ')}
                          </td>
                          <td className="text-[13px] text-slate-500 font-medium">
                            {status}
                          </td>
                          <td className="text-center">
                            <button
                              onClick={() => onStartAdaptivePractice(rec)}
                              className="btn-secondary text-xs py-1.5 px-3.5 cursor-pointer"
                            >
                              {index === 0 ? 'Giải' : 'Tiếp tục'}
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td colSpan={5} className="text-center py-6 text-slate-500 text-sm">
                        Đang tạo danh sách bài tập thích ứng...
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Card 2: Danh sách bài tập mới nhất */}
          <div className="panel">
            <div className="flex items-center justify-between pb-3.5 mb-3.5 border-b border-slate-200">
              <div>
                <h2 className="text-[15px] font-semibold text-slate-900">Bài tập chuẩn hóa mới nhất</h2>
                <span className="text-xs sm:text-[13px] text-slate-500">
                  Tuyển chọn từ ngân hàng đề thi chuẩn GDPT 2018
                </span>
              </div>
              {onNavigateToExercises && (
                <button
                  onClick={onNavigateToExercises}
                  className="text-xs sm:text-[13px] font-medium text-slate-600 hover:text-slate-900 flex items-center space-x-1 cursor-pointer"
                >
                  <span>Xem tất cả</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <div className="overflow-x-auto -mx-1 sm:mx-0">
              <table className="var-table min-w-[520px]">
                <thead>
                  <tr>
                    <th style={{ width: '10%' }}>Mã</th>
                    <th style={{ width: '54%' }}>Tiêu đề bài tập</th>
                    <th style={{ width: '14%' }}>Kết quả của bạn</th>
                    <th style={{ width: '11%' }}>Độ khó</th>
                    <th style={{ width: '11%', textAlign: 'center' }}>Thao tác</th>
                  </tr>
                </thead>
                <tbody>
                  {recentExercises.map((ex, exIdx) => {
                    const diffClass =
                      ex.difficulty === 'easy'
                        ? 'badge-diff-easy'
                        : ex.difficulty === 'medium'
                        ? 'badge-diff-medium'
                        : 'badge-diff-hard';
                    const diffLabel =
                      ex.difficulty === 'easy'
                        ? 'Dễ'
                        : ex.difficulty === 'medium'
                        ? 'Vừa'
                        : 'Khó';

                    const stat = questionStats[ex.question.id];
                    const personalAccuracy = stat && stat.attempts > 0
                      ? `${Math.round((stat.correct / stat.attempts) * 100)}%`
                      : 'Chưa làm';

                    return (
                      <tr key={`${ex.id}-${exIdx}`}>
                        <td className="font-mono text-[13px] font-medium text-slate-500">{ex.displayId}</td>
                        <td className="font-medium text-slate-900 text-[15px] leading-relaxed">{ex.title}</td>
                        <td className="font-mono text-[13px] font-medium text-slate-600">{personalAccuracy}</td>
                        <td>
                          <span className={diffClass}>{diffLabel}</span>
                        </td>
                        <td className="text-center">
                          <button
                            onClick={() => {
                              onStartAdaptivePractice({
                                question: ex.question,
                                score: 0.85,
                                reasons: {
                                  weaknessScore: 0.8,
                                  recencyScore: 0.6,
                                  difficultyFitScore: 0.9,
                                  importanceScore: 0.7,
                                  textExplanation: 'Bài tập nằm trong danh mục ôn luyện trọng tâm.',
                                },
                              });
                            }}
                            className="btn-secondary text-xs py-1.5 px-3 cursor-pointer"
                          >
                            Luyện
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Card 3: Lộ trình thích ứng 7 ngày (7-Day Adaptive Roadmap) */}
          <div className="panel">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-200">
              <h2 className="text-sm font-semibold text-slate-900">
                Lộ trình học tập thích ứng 7 ngày
              </h2>
              <button
                onClick={onNavigateToKnowledgeMap}
                className="text-xs text-slate-600 hover:text-slate-900 font-medium cursor-pointer flex items-center space-x-1"
              >
                <span>Xem bản đồ tri thức</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {learningPath.length === 0 ? (
              <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50 p-6 text-center">
                <Brain className="w-7 h-7 mx-auto text-blue-500 mb-2" />
                <p className="font-semibold text-slate-800 text-sm">Chưa có lộ trình cá nhân hóa</p>
                <p className="text-xs text-slate-500 mt-1">Làm bài đánh giá đầu vào để AI biết bạn yếu gì, muốn đạt gì và có bao nhiêu thời gian mỗi ngày.</p>
                <button onClick={onOpenDiagnostic} className="btn mt-3 text-xs py-2 px-4 cursor-pointer">Tạo lộ trình AI</button>
              </div>
            ) : (
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5 mt-2">
              {learningPath.map((day) => {
                const isToday = day.status === 'in_progress';
                const isCompleted = day.status === 'completed';

                return (
                  <div
                    key={day.dayNumber}
                    className={`p-2.5 rounded-lg border text-xs flex flex-col justify-between ${
                      isToday
                        ? 'bg-slate-50 border-slate-900 shadow-xs'
                        : isCompleted
                        ? 'bg-white border-slate-200 opacity-80'
                        : 'bg-white border-slate-200'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between pb-1.5 border-b border-slate-100">
                        <span className={`font-mono text-xs font-semibold ${isToday ? 'text-slate-900' : 'text-slate-500'}`}>
                          Ngày {day.dayNumber}
                        </span>
                        {isCompleted && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />}
                        {isToday && <span className="w-1.5 h-1.5 rounded-full bg-slate-900" />}
                      </div>
                      <p className="font-medium text-slate-900 mt-1.5 line-clamp-2 text-xs leading-snug">
                        {day.conceptName}
                      </p>
                      <p className="font-mono text-[11px] text-slate-500 mt-1.5">
                        {day.targetMinutes}p • {day.questionCount} câu
                      </p>
                      {day.activity && <p className="text-[10px] text-slate-500 mt-2 leading-snug line-clamp-3">{day.activity}</p>}
                    </div>

                    <div className="mt-2.5 pt-1.5 border-t border-slate-100">
                      {isToday ? (
                        <button
                          onClick={() => onStartLearningDay ? onStartLearningDay(day) : onStartAdaptivePractice()}
                          className="w-full btn text-[11px] py-1 px-1 cursor-pointer"
                        >
                          Học ngay
                        </button>
                      ) : (
                        <span className="text-[11px] text-slate-400 block text-center py-0.5 font-medium">
                          {isCompleted ? 'Hoàn thành' : 'Kế tiếp'}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: ASIDE (Mục tiêu & Tiến độ, Bảng Xếp Hạng, Thông báo, 3 Điểm yếu) */}
        <aside className="space-y-6">
          {/* Card 1: Mục tiêu & Tiến độ học tập */}
          <div className="panel">
            <div className="flex items-center justify-between pb-3.5 mb-3.5 border-b border-slate-200">
              <h2 className="text-[15px] font-semibold text-slate-900">Mục tiêu & Tiến độ</h2>
              <span className="text-xs text-slate-500 font-medium">Kỳ thi THPT</span>
            </div>

            <div className="space-y-3.5 text-[13.5px]">
              <div className="flex justify-between items-baseline">
                <span className="text-slate-600 font-medium">Năng lực ước lượng:</span>
                <span className="font-mono text-base font-bold text-slate-900">
                  {estimatedScore === null ? 'Chưa có dữ liệu' : <>{estimatedScore.toFixed(1)} <span className="text-xs font-normal text-slate-400">/ 10.0</span></>}
                </span>
              </div>
              <div className="flex justify-between items-center gap-3">
                <span className="text-slate-600 font-medium">Mục tiêu điểm số:</span>
                {user.targetScore == null ? (
                  <button
                    onClick={onSetTargetScore}
                    className="text-xs font-semibold text-blue-600 hover:text-blue-700"
                  >
                    Chưa đặt · Đặt mục tiêu
                  </button>
                ) : (
                  <button
                    onClick={onSetTargetScore}
                    className="font-mono text-base font-bold text-slate-900 hover:text-blue-600"
                    title="Thay đổi mục tiêu"
                  >
                    {user.targetScore.toFixed(1)}
                  </button>
                )}
              </div>

              {/* Progress bar towards target */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs text-slate-500">
                  <span>Tiến độ đạt mục tiêu</span>
                  <span className="font-mono font-medium">{user.targetScore == null ? '—' : `${progressPercent}%`}</span>
                </div>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  {user.targetScore != null && (
                    <div
                      className="h-full bg-slate-900 rounded-full transition-all duration-500"
                      style={{ width: `${progressPercent}%` }}
                    />
                  )}
                </div>
              </div>

              <div className="pt-2.5 border-t border-slate-100 space-y-2.5 text-slate-600 text-[13px]">
                <div className="flex justify-between">
                  <span>Khoảng cách mục tiêu:</span>
                  <span className="font-medium text-slate-800">
                    {estimatedScore === null || user.targetScore == null
                      ? 'Chưa có dữ liệu'
                      : user.targetScore > estimatedScore
                        ? `Cần thêm +${(user.targetScore - estimatedScore).toFixed(1)}đ`
                        : 'Đã đạt mục tiêu'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Số câu hỏi đã hoàn thành:</span>
                  <span className="font-mono font-semibold text-slate-900">
                    {user.completedQuestionsCount} câu
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Chế độ thuật toán:</span>
                  <span className="font-medium text-slate-800">Thích ứng Bayesian (BKT)</span>
                </div>
              </div>

              <button
                onClick={onStartExam}
                className="w-full btn mt-2.5 text-xs py-2.5 justify-center cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-white" />
                <span>Vào phòng thi 50 phút</span>
              </button>
            </div>
          </div>

          {/* Card 2: Bảng xếp hạng */}
          <div className="panel">
            <div className="flex items-center justify-between pb-3.5 mb-3.5 border-b border-slate-200">
              <div className="flex items-center space-x-2">
                <Trophy className="w-4 h-4 text-amber-500 shrink-0" />
                <h2 className="text-[15px] font-semibold text-slate-900">Bảng vàng</h2>
              </div>
            </div>
            <div className="flex min-h-28 items-center justify-center rounded-lg border border-dashed border-slate-200 bg-slate-50/60 px-4 text-center">
              <p className="text-sm text-slate-500">{LEADERBOARD_EMPTY_STATE}</p>
            </div>
          </div>

          {/* Card 3: Thông báo */}
          <div className="panel">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-200">
              <h2 className="text-sm font-semibold text-slate-900">Thông báo học tập</h2>
              <span className="text-[11px] text-slate-500 font-medium">Hôm nay</span>
            </div>
            <div className="space-y-2.5 text-xs text-slate-600">
              <div className="p-2.5 rounded border border-slate-200 bg-slate-50/50">
                <p className="font-medium text-slate-800">Cấu trúc đề minh họa 2025</p>
                <p className="text-slate-500 mt-0.5 text-[11px]">Phần I Trắc nghiệm 4 lựa chọn (6đ) + Phần II Đúng/Sai (4đ).</p>
              </div>
              <div className="p-2.5 rounded border border-slate-200 bg-slate-50/50">
                <p className="font-medium text-slate-800">Trọng tâm ôn luyện tuần này</p>
                <p className="text-slate-500 mt-0.5 text-[11px]">Tập trung chuyên đề Hệ CSDL Quan hệ & Truy vấn SQL nâng cao.</p>
              </div>
              <div className="p-2.5 rounded border border-slate-200 bg-slate-50/50">
                <p className="font-medium text-slate-800">Trợ lý AI vi mô</p>
                <p className="text-slate-500 mt-0.5 text-[11px]">Sẵn sàng tạo video tóm tắt kiến thức 3 phút theo yêu cầu.</p>
              </div>
            </div>
          </div>

          {/* Card 4: 3 Điểm yếu cần khắc phục */}
          <div className="panel">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-200">
              <h2 className="text-sm font-semibold text-slate-900">3 Điểm yếu cần củng cố</h2>
              <AlertTriangle className="w-4 h-4 text-amber-600" />
            </div>
            <p className="text-xs text-slate-500 mb-3">
              Nhận diện tự động từ các câu làm sai và thời gian phản xạ.
            </p>

            <div className="space-y-2.5">
              {weakConcepts.length === 0 ? (
                <div className="rounded-lg border border-dashed border-slate-200 bg-slate-50/60 px-4 py-5 text-center">
                  <p className="text-sm font-medium text-slate-700">Chưa có dữ liệu học tập</p>
                  <p className="text-xs text-slate-500 mt-1">Làm một vài câu hỏi để hệ thống bắt đầu phân tích điểm yếu.</p>
                </div>
              ) : (
                weakConcepts.map(({ concept, score }) => (
                  <div key={concept.id} className="p-2.5 bg-slate-50/80 border border-slate-200 rounded-lg">
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <span className="font-medium text-slate-900 truncate max-w-[180px]" title={concept.name}>
                        {concept.name}
                      </span>
                      <span className={score < 50 ? 'status-gap' : 'status-caution'}>
                        {score}%
                      </span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${score < 50 ? 'bg-rose-500' : 'bg-amber-500'}`}
                        style={{ width: `${Math.max(10, score)}%` }}
                      />
                    </div>
                  </div>
                ))
              )}
            </div>

            <button
              onClick={onNavigateToKnowledgeMap}
              className="w-full btn-secondary mt-3.5 text-xs py-2 cursor-pointer flex items-center justify-center gap-1.5"
            >
              <span>Xem phân tích bản đồ tri thức</span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-500" />
            </button>
          </div>
        </aside>
      </div>
    </div>
  );
};
