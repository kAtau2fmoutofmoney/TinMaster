import React, { useState, useMemo, useRef } from 'react';
import {
  ExamCatalogItem,
  ExamCategory,
  ExamDifficulty,
} from '../data/examCatalogData';
import {
  ExamBlueprint,
  Question,
  DifficultyLevel,
  CognitiveLevel,
} from '../types';
import { SAMPLE_QUESTION_BANK } from '../data/questionBank';
import {
  ExerciseExtractionError,
  extractQuestionsFromFile,
} from '../services/exerciseService';
import {
  PlusCircle,
  X,
  Clock,
  FileText,
  Calendar,
  Layers,
  AlertCircle,
  AlertTriangle,
  GraduationCap,
  Shuffle,
  Upload,
  CheckCircle2,
  Loader2,
  Sparkles,
  Trash2,
  Check,
  ArrowRight,
  RotateCcw,
  FileType,
  Image as ImageIcon,
  SlidersHorizontal,
  HelpCircle,
} from 'lucide-react';

interface CreateExamModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveExam: (newExam: ExamCatalogItem) => void;
  availableQuestions?: Question[];
}

const TOPICS = [
  'Tổng hợp toàn diện kiến thức THPT GDPT 2018',
  'Trí tuệ nhân tạo (AI) & Học máy',
  'Thiết kế & Phát triển trang Web',
  'Cơ sở dữ liệu quan hệ (RDBMS)',
  'Ngôn ngữ truy vấn SQL',
  'Lập trình Python căn bản',
  'Mạng máy tính & Giao thức truyền thông',
  'Đạo đức, Pháp luật & Văn hóa số',
];

export const CreateExamModal: React.FC<CreateExamModalProps> = ({
  isOpen,
  onClose,
  onSaveExam,
  availableQuestions,
}) => {
  // Question Source: Option A (bank_shuffle) vs Option B (upload_custom)
  const [questionSource, setQuestionSource] = useState<'bank_shuffle' | 'upload_custom'>('bank_shuffle');

  // Shared Fields
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [category, setCategory] = useState<ExamCategory>('test_45m');
  const [durationMinutes, setDurationMinutes] = useState<number>(45);
  const [targetGrade, setTargetGrade] = useState<10 | 11 | 12 | 'all'>(12);
  const [openDate, setOpenDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [closeDate, setCloseDate] = useState<string>(
    new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString().split('T')[0]
  );

  // Option A Specific Fields
  const [difficulty, setDifficulty] = useState<ExamDifficulty>('standard');
  const [topicName, setTopicName] = useState(TOPICS[0]);
  const [section1Count, setSection1Count] = useState<number>(16);
  const [section2Count, setSection2Count] = useState<number>(4);
  const [shuffledVariantsCount, setShuffledVariantsCount] = useState<number>(3); // 1, 2, 3, 4 variants

  // Option B Specific Fields (Upload & OCR/AI)
  const [mainQuestionFile, setMainQuestionFile] = useState<File | null>(null);
  const [answerKeyFile, setAnswerKeyFile] = useState<File | null>(null);
  const [uploadStep, setUploadStep] = useState<'upload' | 'extracting' | 'review'>('upload');
  const [uploadedQuestions, setUploadedQuestions] = useState<Question[]>([]);
  const [isReviewedConfirmed, setIsReviewedConfirmed] = useState<boolean>(false);
  const [reviewFilter, setReviewFilter] = useState<'all' | 'part1' | 'part2'>('all');
  const [isDragOverMain, setIsDragOverMain] = useState(false);
  const [isDragOverKey, setIsDragOverKey] = useState(false);
  const [extractError, setExtractError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const keyInputRef = useRef<HTMLInputElement>(null);
  const extractionInProgressRef = useRef(false);

  // General Form Error
  const [formError, setFormError] = useState<string | null>(null);

  // Bank pool for validation
  const bankPool = useMemo(() => {
    return availableQuestions && availableQuestions.length > 0
      ? availableQuestions
      : SAMPLE_QUESTION_BANK;
  }, [availableQuestions]);

  // Calculate available questions in bank for current filter
  const availableCount = useMemo(() => {
    const pool = bankPool.filter((q) => {
      if (targetGrade !== 'all' && q.grade && q.grade !== targetGrade) {
        return false;
      }
      if (topicName !== 'Tổng hợp toàn diện kiến thức THPT GDPT 2018') {
        if (topicName === 'Trí tuệ nhân tạo (AI) & Học máy') return q.topicId === 'AI_FUNDAMENTALS';
        if (topicName === 'Thiết kế & Phát triển trang Web') return q.topicId === 'WEB_DEVELOPMENT';
        if (topicName === 'Cơ sở dữ liệu quan hệ (RDBMS)') return q.topicId === 'RELATIONAL_DATABASE';
        if (topicName === 'Ngôn ngữ truy vấn SQL') return q.topicId === 'SQL_QUERIES';
        if (topicName === 'Lập trình Python căn bản') return q.topicId === 'PYTHON_PROGRAMMING';
        if (topicName === 'Mạng máy tính & Giao thức truyền thông') return q.topicId === 'COMPUTER_NETWORK';
        if (topicName === 'Đạo đức, Pháp luật & Văn hóa số') return q.topicId === 'CYBER_SECURITY';
      }
      return true;
    });

    const s1 = pool.filter((q) => q.questionType === 'single_choice').length;
    const s2 = pool.filter((q) => q.questionType === 'true_false_multistatement').length;
    return {
      section1: s1,
      section2: s2,
      total: pool.length,
    };
  }, [bankPool, targetGrade, topicName]);

  // Inline warning check for Option A
  const hasShortfall = useMemo(() => {
    if (questionSource !== 'bank_shuffle') return false;
    return (
      section1Count > availableCount.section1 ||
      section2Count > availableCount.section2
    );
  }, [questionSource, section1Count, section2Count, availableCount]);

  if (!isOpen) return null;

  // Preset switch
  const handleCategoryChange = (cat: ExamCategory) => {
    setCategory(cat);
    if (cat === 'test_15m') {
      setDurationMinutes(15);
      setSection1Count(10);
      setSection2Count(0);
    } else if (cat === 'test_45m') {
      setDurationMinutes(45);
      setSection1Count(16);
      setSection2Count(4);
    } else if (cat === 'national_standard') {
      setDurationMinutes(50);
      setSection1Count(24);
      setSection2Count(4);
    } else if (cat === 'survey') {
      setDurationMinutes(20);
      setSection1Count(15);
      setSection2Count(0);
    }
  };

  // Format file size
  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  // Convert File to Base64
  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (err) => reject(err);
      reader.readAsDataURL(file);
    });
  };

  // Run AI & OCR Extraction for Option B
  const handleStartExtraction = async () => {
    if (extractionInProgressRef.current || uploadStep === 'extracting') return;
    if (!mainQuestionFile) {
      setExtractError('Vui lòng chọn tệp tin đề thi (.docx, .pdf, hoặc hình ảnh) trước.');
      return;
    }

    extractionInProgressRef.current = true;
    setExtractError(null);
    setUploadStep('extracting');

    try {
      const base64Data = await fileToBase64(mainQuestionFile);
      let answerKeyPayload: any = undefined;

      if (answerKeyFile) {
        try {
          const keyB64 = await fileToBase64(answerKeyFile);
          answerKeyPayload = {
            name: answerKeyFile.name,
            mimeType: answerKeyFile.type,
            base64: keyB64,
          };
        } catch {}
      }

      const data = await extractQuestionsFromFile(
        {
          name: mainQuestionFile.name,
          mimeType: mainQuestionFile.type,
          base64: base64Data,
        },
        answerKeyPayload
      );

      if (data.success && Array.isArray(data.questions) && data.questions.length > 0) {
        setUploadedQuestions(data.questions);
        setUploadStep('review');
        setIsReviewedConfirmed(false);
      } else {
        setUploadedQuestions([]);
        setExtractError(data.error || 'Không tìm thấy câu hỏi hợp lệ trong tài liệu.');
        setUploadStep('upload');
      }
    } catch (err: unknown) {
      setUploadedQuestions([]);
      setExtractError(
        err instanceof ExerciseExtractionError
          ? err.message
          : 'Không thể đọc tệp đã chọn. Tệp vẫn được giữ lại; vui lòng thử lại.'
      );
      setUploadStep('upload');
    } finally {
      extractionInProgressRef.current = false;
    }
  };

  // Option B Question Editing
  const handleUpdateStem = (index: number, newStem: string) => {
    setUploadedQuestions((prev) => {
      const copy = [...prev];
      copy[index] = { ...copy[index], stem: newStem };
      return copy;
    });
  };

  const handleSelectOptionCorrect = (qIndex: number, optLabel: 'A' | 'B' | 'C' | 'D') => {
    setUploadedQuestions((prev) => {
      const copy = [...prev];
      const q = { ...copy[qIndex] };
      if (q.singleChoiceOptions) {
        q.singleChoiceOptions = q.singleChoiceOptions.map((opt) => ({
          ...opt,
          isCorrect: opt.label === optLabel,
        }));
      }
      copy[qIndex] = q;
      return copy;
    });
  };

  const handleToggleTrueFalse = (qIndex: number, subOrder: 'a' | 'b' | 'c' | 'd', isCorrect: boolean) => {
    setUploadedQuestions((prev) => {
      const copy = [...prev];
      const q = { ...copy[qIndex] };
      if (q.trueFalseStatements) {
        q.trueFalseStatements = q.trueFalseStatements.map((st) =>
          st.subOrder === subOrder ? { ...st, isCorrect } : st
        );
      }
      copy[qIndex] = q;
      return copy;
    });
  };

  const handleDeleteUploadedQuestion = (index: number) => {
    setUploadedQuestions((prev) => prev.filter((_, idx) => idx !== index));
  };

  // Option B Counts
  const uploadedPart1Count = useMemo(() => {
    return uploadedQuestions.filter((q) => q.questionType === 'single_choice').length;
  }, [uploadedQuestions]);

  const uploadedPart2Count = useMemo(() => {
    return uploadedQuestions.filter((q) => q.questionType === 'true_false_multistatement').length;
  }, [uploadedQuestions]);

  // Filtered list for review view
  const filteredReviewQuestions = useMemo(() => {
    if (reviewFilter === 'part1') return uploadedQuestions.filter((q) => q.questionType === 'single_choice');
    if (reviewFilter === 'part2') return uploadedQuestions.filter((q) => q.questionType === 'true_false_multistatement');
    return uploadedQuestions;
  }, [uploadedQuestions, reviewFilter]);

  // Form Submit Handler
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!title.trim()) {
      setFormError('Vui lòng nhập tên kỳ thi / bài kiểm tra.');
      return;
    }

    if (questionSource === 'bank_shuffle') {
      const totalQ = section1Count + section2Count;
      if (totalQ <= 0) {
        setFormError('Số lượng câu hỏi phải lớn hơn 0.');
        return;
      }

      if (hasShortfall) {
        setFormError(
          `Ngân hàng câu hỏi hiện không đủ số lượng câu hỏi yêu cầu (Có: ${availableCount.section1} câu P1, ${availableCount.section2} câu P2; Yêu cầu: ${section1Count} câu P1, ${section2Count} câu P2). Vui lòng điều chỉnh lại số lượng hoặc chọn chuyên đề 'Tổng hợp toàn diện'.`
        );
        return;
      }

      const customBlueprint: ExamBlueprint = {
        id: `BP_CUSTOM_${Date.now()}`,
        title: title.trim(),
        academicYear: 2025,
        durationMinutes,
        totalQuestions: totalQ,
        totalScore: 10.0,
        sections: {
          sectionI: {
            name: 'Phần I: Câu trắc nghiệm 4 lựa chọn',
            questionCount: section1Count,
            scorePerQuestion: section1Count > 0 ? (section2Count > 0 ? 6.0 / section1Count : 10.0 / section1Count) : 0,
          },
          sectionII: {
            name: 'Phần II: Câu trắc nghiệm Đúng/Sai',
            questionCount: section2Count,
            scoringRules: {
              oneCorrect: 0.1,
              twoCorrect: 0.25,
              threeCorrect: 0.5,
              fourCorrect: section2Count > 0 ? 4.0 / section2Count : 0,
            },
          },
        },
        topicDistribution: {
          [topicName]: totalQ,
        },
      };

      const newExam: ExamCatalogItem = {
        id: `exam-custom-${Date.now()}`,
        title: title.trim(),
        subtitle: subtitle.trim() || `Bài thi Tin học THPT - Khối ${targetGrade === 'all' ? '10-11-12' : targetGrade}`,
        category,
        durationMinutes,
        totalQuestions: totalQ,
        totalScore: 10.0,
        section1Count,
        section2Count,
        difficulty,
        difficultyLabel:
          difficulty === 'basic'
            ? 'Cơ bản - Nhận biết'
            : difficulty === 'standard'
            ? 'Chuẩn năng lực GDPT'
            : difficulty === 'advanced'
            ? 'Vận dụng cao (8+)'
            : 'Tổng hợp',
        topicName,
        status: 'open',
        openDate,
        closeDate,
        targetGrade,
        isCustom: true,
        blueprint: customBlueprint,
        attemptsCount: 0,
        averageScore: 0,
        questionSource: 'bank_shuffle',
        shuffledVariantsCount,
      };

      onSaveExam(newExam);
      onClose();
    } else {
      // Option B Submit
      if (uploadedQuestions.length === 0) {
        setFormError('Vui lòng tải lên tệp đề thi và hoàn tất quá trình trích xuất câu hỏi.');
        return;
      }
      if (!isReviewedConfirmed) {
        setFormError('Vui lòng tích chọn xác nhận đã rà soát câu hỏi và đáp án trước khi xuất bản.');
        return;
      }

      const totalQ = uploadedQuestions.length;
      const s1Count = uploadedPart1Count;
      const s2Count = uploadedPart2Count;

      const customBlueprint: ExamBlueprint = {
        id: `BP_UPLOAD_${Date.now()}`,
        title: title.trim(),
        academicYear: 2025,
        durationMinutes,
        totalQuestions: totalQ,
        totalScore: 10.0,
        sections: {
          sectionI: {
            name: 'Phần I: Câu trắc nghiệm 4 lựa chọn',
            questionCount: s1Count,
            scorePerQuestion: s1Count > 0 ? (s2Count > 0 ? 6.0 / s1Count : 10.0 / s1Count) : 0,
          },
          sectionII: {
            name: 'Phần II: Câu trắc nghiệm Đúng/Sai',
            questionCount: s2Count,
            scoringRules: {
              oneCorrect: 0.1,
              twoCorrect: 0.25,
              threeCorrect: 0.5,
              fourCorrect: s2Count > 0 ? 4.0 / s2Count : 0,
            },
          },
        },
        topicDistribution: {
          'Đề thi giáo viên tải lên': totalQ,
        },
      };

      const newExam: ExamCatalogItem = {
        id: `exam-upload-${Date.now()}`,
        title: title.trim(),
        subtitle: subtitle.trim() || `Đề thi số hóa từ tệp ${mainQuestionFile?.name || 'tài liệu'} - Khối ${targetGrade === 'all' ? '10-11-12' : targetGrade}`,
        category,
        durationMinutes,
        totalQuestions: totalQ,
        totalScore: 10.0,
        section1Count: s1Count,
        section2Count: s2Count,
        difficulty: 'standard',
        difficultyLabel: 'Đề thi giáo viên tải lên',
        topicName: 'Đề thi giáo viên tải lên',
        status: 'open',
        openDate,
        closeDate,
        targetGrade,
        isCustom: true,
        blueprint: customBlueprint,
        attemptsCount: 0,
        averageScore: 0,
        questionSource: 'upload_custom',
        sourceFileName: mainQuestionFile?.name,
        questions: uploadedQuestions,
      };

      onSaveExam(newExam);
      onClose();
    }
  };

  // Determine submit disabled state
  const isSubmitDisabled = useMemo(() => {
    if (!title.trim()) return true;
    if (questionSource === 'bank_shuffle') {
      if (section1Count + section2Count <= 0) return true;
      if (hasShortfall) return true;
      return false;
    } else {
      // Option B
      return uploadedQuestions.length === 0 || !isReviewedConfirmed;
    }
  }, [
    title,
    questionSource,
    section1Count,
    section2Count,
    hasShortfall,
    uploadedQuestions.length,
    isReviewedConfirmed,
  ]);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50/80 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
              <PlusCircle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900">
                Tạo Kỳ Thi / Đề Kiểm Tra Mới
              </h2>
              <p className="text-xs text-slate-500">
                Lựa chọn nguồn đề bài (ngân hàng câu hỏi hoặc tự tải lên), thiết lập ma trận và thời hạn làm bài.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Form */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5 flex-1">
          {formError && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          {/* SECTION 1: PRESET EXAM CATEGORY */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700">Loại hình kỳ thi:</label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'test_15m', label: '15 phút', desc: '10 câu trắc nghiệm' },
                { id: 'test_45m', label: '1 tiết (45p)', desc: '16 TN + 4 Đ/S' },
                { id: 'national_standard', label: 'Chuẩn 50p', desc: '24 TN + 4 Đ/S (BGDĐT)' },
                { id: 'survey', label: 'Khảo sát', desc: '15 câu nhanh' },
              ].map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleCategoryChange(item.id as ExamCategory)}
                  className={`p-2.5 rounded-xl border text-left cursor-pointer transition ${
                    category === item.id
                      ? 'border-blue-600 bg-blue-50 text-blue-900 font-bold ring-1 ring-blue-600'
                      : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div className="text-xs font-bold">{item.label}</div>
                  <div className="text-[11px] text-slate-500 font-normal">{item.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* SECTION 2: QUESTION SOURCE (NGUỒN CÂU HỎI) */}
          <div className="space-y-1.5 pt-1">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-800">
                Nguồn câu hỏi: <span className="text-red-500">*</span>
              </label>
              <span className="text-[11px] text-slate-400">Chọn phương thức khởi tạo nội dung đề</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Option A Card */}
              <button
                type="button"
                onClick={() => setQuestionSource('bank_shuffle')}
                className={`p-3.5 rounded-xl border text-left cursor-pointer transition flex flex-col justify-between ${
                  questionSource === 'bank_shuffle'
                    ? 'border-blue-600 bg-blue-50/70 text-blue-950 font-medium ring-2 ring-blue-600/40 shadow-xs'
                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50 hover:border-slate-300'
                }`}
              >
                <div className="flex items-start space-x-2.5">
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                      questionSource === 'bank_shuffle'
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    <Shuffle className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold flex items-center space-x-1.5">
                      <span>Random hóa từ ngân hàng câu hỏi</span>
                      {questionSource === 'bank_shuffle' && (
                        <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
                      )}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                      Hệ thống tự động chọn và xáo trộn câu hỏi từ ngân hàng câu hỏi có sẵn theo cấu trúc ma trận bên dưới.
                    </p>
                  </div>
                </div>
              </button>

              {/* Option B Card */}
              <button
                type="button"
                onClick={() => setQuestionSource('upload_custom')}
                className={`p-3.5 rounded-xl border text-left cursor-pointer transition flex flex-col justify-between ${
                  questionSource === 'upload_custom'
                    ? 'border-blue-600 bg-blue-50/70 text-blue-950 font-medium ring-2 ring-blue-600/40 shadow-xs'
                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50 hover:border-slate-300'
                }`}
              >
                <div className="flex items-start space-x-2.5">
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                      questionSource === 'upload_custom'
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    <Upload className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold flex items-center space-x-1.5">
                      <span>Tự tải lên đề thi riêng</span>
                      {questionSource === 'upload_custom' && (
                        <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
                      )}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                      Tải lên tệp đề thi (.docx, .pdf, ảnh) kèm bảng đáp án. Trích xuất AI và kiểm tra câu hỏi trực tiếp.
                    </p>
                  </div>
                </div>
              </button>
            </div>
          </div>

          {/* SECTION 3: SHARED GENERAL FIELDS */}
          <div className="space-y-3.5 pt-1">
            {/* Title */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">
                Tên bài thi / kỳ thi: <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="VD: Kiểm tra 1 tiết Tin học 12 - Chủ đề AI & RDBMS"
                className="w-full text-xs sm:text-sm p-3 rounded-xl border border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              />
            </div>

            {/* Subtitle / Description */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">Mô tả tóm tắt mục tiêu bài thi:</label>
              <input
                type="text"
                value={subtitle}
                onChange={(e) => setSubtitle(e.target.value)}
                placeholder="VD: Kiểm tra định kỳ giữa học kỳ II lớp 12 theo chương trình Tin học GDPT 2018"
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:border-blue-500"
              />
            </div>

            {/* Row: Duration, Target Grade, (Difficulty if Option A) */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Thời gian (phút):
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min={5}
                    max={180}
                    value={durationMinutes}
                    onChange={(e) => setDurationMinutes(Number(e.target.value))}
                    className="w-full text-xs p-2.5 pl-8 rounded-xl border border-slate-300 focus:border-blue-500"
                  />
                  <Clock className="w-4 h-4 text-slate-400 absolute left-2.5 top-3" />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Khối lớp:</label>
                <select
                  value={targetGrade}
                  onChange={(e) => setTargetGrade(e.target.value as any)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-white cursor-pointer"
                >
                  <option value={12}>Lớp 12 (Thi Tốt Nghiệp)</option>
                  <option value={11}>Lớp 11 (RDBMS & Python)</option>
                  <option value={10}>Lớp 10 (Cơ bản)</option>
                  <option value="all">Toàn bộ khối THPT</option>
                </select>
              </div>

              {questionSource === 'bank_shuffle' ? (
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Cấp độ phân hóa:</label>
                  <select
                    value={difficulty}
                    onChange={(e) => setDifficulty(e.target.value as ExamDifficulty)}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-white cursor-pointer"
                  >
                    <option value="standard">Chuẩn GDPT 2018</option>
                    <option value="basic">Cơ bản - Nhận biết</option>
                    <option value="advanced">Vận dụng cao (Phân hóa 8+)</option>
                    <option value="comprehensive">Tổng hợp cuối kỳ</option>
                  </select>
                </div>
              ) : (
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Thang điểm chuẩn:</label>
                  <div className="w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-700 font-semibold flex items-center justify-between">
                    <span>10.0 Điểm</span>
                    <span className="text-[10px] text-blue-600 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                      Tự động cân đối
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* Row: Open and Close Dates */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Ngày mở đề thi:</label>
                <input
                  type="date"
                  value={openDate}
                  onChange={(e) => setOpenDate(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-white"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Hạn chót nộp bài:</label>
                <input
                  type="date"
                  value={closeDate}
                  onChange={(e) => setCloseDate(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-white"
                />
              </div>
            </div>
          </div>

          {/* SECTION 4A: OPTION A - BANK SHUFFLE & MATRIX UI */}
          {questionSource === 'bank_shuffle' && (
            <div className="space-y-4 pt-2 border-t border-slate-200">
              {/* Shuffled Variants Count Selector */}
              <div className="p-3.5 bg-blue-50/50 rounded-xl border border-blue-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div className="space-y-0.5">
                  <div className="text-xs font-bold text-slate-900 flex items-center space-x-1.5">
                    <Shuffle className="w-3.5 h-3.5 text-blue-600" />
                    <span>Số lượng đề trộn (Mã đề hoán vị):</span>
                  </div>
                  <p className="text-[11px] text-slate-500">
                    Tạo các phiên bản hoán vị câu hỏi & đáp án để hạn chế nhìn bài giữa các học sinh ngồi gần.
                  </p>
                </div>

                <div className="flex items-center space-x-1.5 shrink-0">
                  {[
                    { count: 1, label: '1 đề (Cố định)' },
                    { count: 2, label: '2 mã đề' },
                    { count: 3, label: '3 mã đề (Khuyên dùng)' },
                    { count: 4, label: '4 mã đề (Tối đa)' },
                  ].map((variant) => (
                    <button
                      key={variant.count}
                      type="button"
                      onClick={() => setShuffledVariantsCount(variant.count)}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition ${
                        shuffledVariantsCount === variant.count
                          ? 'bg-blue-600 text-white font-bold shadow-xs'
                          : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {variant.count} đề
                    </button>
                  ))}
                </div>
              </div>

              {/* Topic Focus */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-700">Chuyên đề trọng tâm:</label>
                  <span className="text-[11px] text-slate-500">
                    Khả dụng trong ngân hàng: <strong>{availableCount.total}</strong> câu ({availableCount.section1} TN + {availableCount.section2} Đ/S)
                  </span>
                </div>
                <select
                  value={topicName}
                  onChange={(e) => setTopicName(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-white cursor-pointer"
                >
                  {TOPICS.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </div>

              {/* Question Matrix Structure */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2 text-xs font-bold text-slate-800">
                    <Layers className="w-4 h-4 text-blue-600" />
                    <span>Cấu trúc ma trận câu hỏi (Thang điểm 10.0):</span>
                  </div>
                  <span className="text-[11px] text-slate-500">
                    Tổng cộng: <strong>{section1Count + section2Count}</strong> câu
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                      Phần I: Trắc nghiệm 4 lựa chọn:
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        min={0}
                        max={50}
                        value={section1Count}
                        onChange={(e) => setSection1Count(Math.max(0, Number(e.target.value)))}
                        className={`w-full text-xs p-2 rounded-lg border bg-white ${
                          section1Count > availableCount.section1
                            ? 'border-amber-400 focus:border-amber-500'
                            : 'border-slate-300'
                        }`}
                      />
                      <span className="absolute right-3 top-2 text-[10px] text-slate-400">
                        Có sẵn: {availableCount.section1}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-400 mt-0.5 block">
                      (1 đáp án đúng duy nhất, chiếm 6.0 điểm)
                    </span>
                  </div>

                  <div>
                    <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                      Phần II: Câu Đúng / Sai (4 ý con):
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        min={0}
                        max={20}
                        value={section2Count}
                        onChange={(e) => setSection2Count(Math.max(0, Number(e.target.value)))}
                        className={`w-full text-xs p-2 rounded-lg border bg-white ${
                          section2Count > availableCount.section2
                            ? 'border-amber-400 focus:border-amber-500'
                            : 'border-slate-300'
                        }`}
                      />
                      <span className="absolute right-3 top-2 text-[10px] text-slate-400">
                        Có sẵn: {availableCount.section2}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-400 mt-0.5 block">
                      (Chấm lũy tiến 0.1 - 0.25 - 0.5 - 1.0đ, chiếm 4.0 điểm)
                    </span>
                  </div>
                </div>
              </div>

              {/* Inline Warning if Bank doesn't have enough questions */}
              {hasShortfall && (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-800 flex items-start space-x-2.5 animate-in fade-in">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div className="flex-1 space-y-1">
                    <div className="font-bold">Cảnh báo: Số lượng câu hỏi yêu cầu vượt quá ngân hàng có sẵn</div>
                    <p className="text-[11px] text-amber-700 leading-relaxed">
                      Chuyên đề "{topicName}" (Khối {targetGrade === 'all' ? '10-11-12' : targetGrade}) hiện chỉ có{' '}
                      <strong>{availableCount.section1}</strong> câu trắc nghiệm Phần I và{' '}
                      <strong>{availableCount.section2}</strong> câu Đúng/Sai Phần II (tổng: {availableCount.total} câu). Bạn đang yêu cầu{' '}
                      <strong>{section1Count}</strong> câu Phần I và <strong>{section2Count}</strong> câu Phần II.
                    </p>
                    <p className="text-[11px] text-amber-800 font-medium">
                      💡 Giải pháp: Vui lòng giảm số câu xuống hoặc chọn chuyên đề "Tổng hợp toàn diện kiến thức THPT GDPT 2018".
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* SECTION 4B: OPTION B - UPLOAD OWN EXAM & OCR/AI REVIEW */}
          {questionSource === 'upload_custom' && (
            <div className="space-y-4 pt-2 border-t border-slate-200">
              {/* STEP 1: Upload Zones */}
              {uploadStep === 'upload' && (
                <div className="space-y-4">
                  {extractError && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-center space-x-2">
                      <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
                      <span>{extractError}</span>
                    </div>
                  )}

                  {/* Main Question File Dropzone */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-800 flex items-center justify-between">
                      <span>1. Tệp đề thi chính (Bắt buộc): <span className="text-red-500">*</span></span>
                      <span className="text-[11px] font-normal text-slate-400">Định dạng hỗ trợ: .docx, .pdf, .jpg, .jpeg, .png</span>
                    </label>

                    <div
                      onDragOver={(e) => {
                        e.preventDefault();
                        setIsDragOverMain(true);
                      }}
                      onDragLeave={() => setIsDragOverMain(false)}
                      onDrop={(e) => {
                        e.preventDefault();
                        setIsDragOverMain(false);
                        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                          setMainQuestionFile(e.dataTransfer.files[0]);
                          setExtractError(null);
                        }
                      }}
                      onClick={() => fileInputRef.current?.click()}
                      className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition ${
                        isDragOverMain
                          ? 'border-blue-500 bg-blue-50/60'
                          : mainQuestionFile
                          ? 'border-emerald-300 bg-emerald-50/40'
                          : 'border-slate-300 hover:border-blue-400 bg-slate-50/50'
                      }`}
                    >
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept=".docx,.pdf,.jpg,.jpeg,.png"
                        className="hidden"
                        onChange={(e) => {
                          if (e.target.files && e.target.files[0]) {
                            setMainQuestionFile(e.target.files[0]);
                            setExtractError(null);
                          }
                        }}
                      />

                      {mainQuestionFile ? (
                        <div className="flex items-center justify-between bg-white p-3 rounded-lg border border-emerald-200">
                          <div className="flex items-center space-x-2.5 text-left">
                            <div className="w-9 h-9 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xs">
                              {mainQuestionFile.name.endsWith('.docx') ? 'DOCX' : mainQuestionFile.name.endsWith('.pdf') ? 'PDF' : 'IMG'}
                            </div>
                            <div>
                              <div className="text-xs font-bold text-slate-800 truncate max-w-xs sm:max-w-md">
                                {mainQuestionFile.name}
                              </div>
                              <div className="text-[11px] text-slate-500">
                                {formatFileSize(mainQuestionFile.size)} • Sẵn sàng trích xuất
                              </div>
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setMainQuestionFile(null);
                            }}
                            className="p-1 text-slate-400 hover:text-red-600 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ) : (
                        <div className="space-y-1.5">
                          <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mx-auto">
                            <Upload className="w-5 h-5" />
                          </div>
                          <div className="text-xs font-bold text-slate-700">
                            Kéo thả tệp đề thi vào đây, hoặc <span className="text-blue-600 underline">chọn từ máy tính</span>
                          </div>
                          <p className="text-[11px] text-slate-400">
                            Hệ thống tự động nhận dạng Phần I (trắc nghiệm 4 lựa chọn) và Phần II (Đúng/Sai)
                          </p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Optional Answer Key Dropzone */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-800 flex items-center justify-between">
                      <span>2. Tệp đáp án / Bareme chấm (Tùy chọn):</span>
                      <span className="text-[11px] font-normal text-slate-400">Đồng bộ tự động với đề bài</span>
                    </label>

                    <div
                      onDragOver={(e) => {
                        e.preventDefault();
                        setIsDragOverKey(true);
                      }}
                      onDragLeave={() => setIsDragOverKey(false)}
                      onDrop={(e) => {
                        e.preventDefault();
                        setIsDragOverKey(false);
                        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                          setAnswerKeyFile(e.dataTransfer.files[0]);
                        }
                      }}
                      onClick={() => keyInputRef.current?.click()}
                      className={`border border-dashed rounded-xl p-4 text-center cursor-pointer transition ${
                        isDragOverKey
                          ? 'border-blue-500 bg-blue-50/50'
                          : answerKeyFile
                          ? 'border-blue-300 bg-blue-50/30'
                          : 'border-slate-200 hover:border-slate-300 bg-slate-50/30'
                      }`}
                    >
                      <input
                        ref={keyInputRef}
                        type="file"
                        accept=".docx,.pdf,.jpg,.jpeg,.png"
                        className="hidden"
                        onChange={(e) => {
                          if (e.target.files && e.target.files[0]) {
                            setAnswerKeyFile(e.target.files[0]);
                          }
                        }}
                      />

                      {answerKeyFile ? (
                        <div className="flex items-center justify-between bg-white p-2.5 rounded-lg border border-blue-200">
                          <div className="flex items-center space-x-2 text-left">
                            <FileText className="w-4 h-4 text-blue-600" />
                            <div className="text-xs font-semibold text-slate-800 truncate max-w-xs">
                              {answerKeyFile.name} ({formatFileSize(answerKeyFile.size)})
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setAnswerKeyFile(null);
                            }}
                            className="p-1 text-slate-400 hover:text-red-600 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div className="text-[11px] text-slate-500 flex items-center justify-center space-x-2">
                          <FileText className="w-3.5 h-3.5 text-slate-400" />
                          <span>Nhấp để đính kèm tệp đáp án nếu có bảng riêng (.docx, .pdf, ảnh)</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Extract Button */}
                  <div className="pt-2 flex justify-end">
                    <button
                      type="button"
                      onClick={handleStartExtraction}
                      disabled={!mainQuestionFile}
                      className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-400 text-white text-xs font-bold rounded-xl transition cursor-pointer flex items-center space-x-2 shadow-xs"
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>{extractError ? 'Thử lại trích xuất' : 'Trích Xuất Câu Hỏi Bằng AI & OCR'}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 2: Extracting Loader */}
              {uploadStep === 'extracting' && (
                <div className="p-8 text-center space-y-4 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="w-12 h-12 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mx-auto animate-spin">
                    <Loader2 className="w-6 h-6" />
                  </div>
                  <div className="space-y-1">
                    <h3 className="text-sm font-bold text-slate-800">
                      Đang xử lý tài liệu và trích xuất câu hỏi...
                    </h3>
                    <p className="text-xs text-slate-500 max-w-md mx-auto">
                      Hệ thống đang chạy mô hình thị giác AI & OCR để nhận diện công thức, phân loại trắc nghiệm Phần I và câu hỏi Đúng/Sai Phần II.
                    </p>
                  </div>
                  <div className="w-48 h-1.5 bg-slate-200 rounded-full mx-auto overflow-hidden">
                    <div className="h-full bg-blue-600 rounded-full animate-pulse w-3/4" />
                  </div>
                </div>
              )}

              {/* STEP 3: Review & Confirmation Screen */}
              {uploadStep === 'review' && (
                <div className="space-y-4 animate-in fade-in">
                  {/* Top Stats Banner */}
                  <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                    <div className="space-y-0.5">
                      <div className="flex items-center space-x-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span className="text-xs font-bold text-emerald-950">
                          Đã trích xuất thành công {uploadedQuestions.length} câu hỏi
                        </span>
                      </div>
                      <p className="text-[11px] text-emerald-800">
                        Phần I: <strong>{uploadedPart1Count}</strong> câu trắc nghiệm • Phần II: <strong>{uploadedPart2Count}</strong> câu Đúng/Sai
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setUploadStep('upload');
                        setIsReviewedConfirmed(false);
                      }}
                      className="px-3 py-1.5 bg-white border border-emerald-300 hover:bg-emerald-100/50 text-emerald-800 text-xs font-semibold rounded-lg transition cursor-pointer flex items-center space-x-1.5 self-start sm:self-auto"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Tải lại file khác</span>
                    </button>
                  </div>

                  {/* Weighting Confirmation & Mismatch Warning */}
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs">
                    <div className="flex items-center justify-between font-bold text-slate-800">
                      <span>Cơ cấu điểm số đề thi (Chuẩn 10.0đ):</span>
                      <span className="text-blue-600">Tổng điểm: 10.0đ</span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600">
                      <div className="p-2 bg-white rounded-lg border border-slate-200">
                        <span className="font-semibold block text-slate-800">Phần I (Trắc nghiệm):</span>
                        <span>
                          {uploadedPart1Count} câu •{' '}
                          {uploadedPart2Count > 0 ? '6.0 điểm' : '10.0 điểm'}{' '}
                          ({uploadedPart1Count > 0 ? ((uploadedPart2Count > 0 ? 6.0 : 10.0) / uploadedPart1Count).toFixed(2) : 0}đ/câu)
                        </span>
                      </div>
                      <div className="p-2 bg-white rounded-lg border border-slate-200">
                        <span className="font-semibold block text-slate-800">Phần II (Đúng / Sai):</span>
                        <span>
                          {uploadedPart2Count} câu •{' '}
                          {uploadedPart2Count > 0 ? '4.0 điểm (thang lũy tiến)' : '0 điểm'}
                        </span>
                      </div>
                    </div>

                    {/* Mismatch Warning if counts deviate from typical 16/4 or 24/4 */}
                    {uploadedPart1Count !== 16 && uploadedPart1Count !== 24 && (
                      <div className="p-2 bg-amber-50 rounded-lg border border-amber-200 text-[11px] text-amber-800 flex items-center space-x-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                        <span>
                          Lưu ý: Số lượng câu hỏi tải lên ({uploadedPart1Count} câu Phần I, {uploadedPart2Count} câu Phần II) khác cấu trúc mẫu. Hệ thống đã tự động cân đối thang điểm để tổng điểm đạt đúng 10.0 điểm.
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Filter tabs */}
                  <div className="flex items-center justify-between pt-1">
                    <div className="text-xs font-bold text-slate-700">
                      Danh sách câu hỏi cần rà soát ({filteredReviewQuestions.length}):
                    </div>
                    <div className="flex items-center space-x-1 bg-slate-100 p-0.5 rounded-lg text-[11px]">
                      <button
                        type="button"
                        onClick={() => setReviewFilter('all')}
                        className={`px-2.5 py-1 rounded-md transition cursor-pointer ${
                          reviewFilter === 'all'
                            ? 'bg-white font-bold text-slate-900 shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        Tất cả ({uploadedQuestions.length})
                      </button>
                      <button
                        type="button"
                        onClick={() => setReviewFilter('part1')}
                        className={`px-2.5 py-1 rounded-md transition cursor-pointer ${
                          reviewFilter === 'part1'
                            ? 'bg-white font-bold text-slate-900 shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        Phần I ({uploadedPart1Count})
                      </button>
                      <button
                        type="button"
                        onClick={() => setReviewFilter('part2')}
                        className={`px-2.5 py-1 rounded-md transition cursor-pointer ${
                          reviewFilter === 'part2'
                            ? 'bg-white font-bold text-slate-900 shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        Phần II ({uploadedPart2Count})
                      </button>
                    </div>
                  </div>

                  {/* Question items list */}
                  <div className="max-h-72 overflow-y-auto space-y-3 pr-1">
                    {filteredReviewQuestions.map((q, idx) => {
                      const realIndex = uploadedQuestions.findIndex((item) => item.id === q.id);
                      return (
                        <div
                          key={q.id ? `${q.id}-${idx}` : `q-${idx}`}
                          className="p-3 bg-white border border-slate-200 rounded-xl space-y-2.5 shadow-2xs hover:border-slate-300 transition"
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex items-center space-x-2">
                              <span className="w-6 h-6 rounded-md bg-blue-100 text-blue-800 font-bold text-xs flex items-center justify-center shrink-0">
                                {realIndex + 1}
                              </span>
                              <span className="text-[11px] font-semibold text-slate-600">
                                {q.questionType === 'single_choice' ? 'Phần I: 4 lựa chọn' : 'Phần II: Đúng / Sai'}
                              </span>
                            </div>

                            <button
                              type="button"
                              onClick={() => handleDeleteUploadedQuestion(realIndex)}
                              className="text-slate-400 hover:text-red-600 transition p-1 cursor-pointer"
                              title="Xóa câu hỏi này"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          {/* Editable Question Stem */}
                          <textarea
                            rows={2}
                            value={q.stem}
                            onChange={(e) => handleUpdateStem(realIndex, e.target.value)}
                            className="w-full text-xs p-2 rounded-lg border border-slate-200 focus:border-blue-500 bg-slate-50/50"
                          />

                          {/* Single Choice Options Editor */}
                          {q.questionType === 'single_choice' && q.singleChoiceOptions && (
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                              {q.singleChoiceOptions.map((opt) => (
                                <button
                                  key={opt.label}
                                  type="button"
                                  onClick={() => handleSelectOptionCorrect(realIndex, opt.label as any)}
                                  className={`p-2 rounded-lg border text-left cursor-pointer flex items-center space-x-2 text-xs transition ${
                                    opt.isCorrect
                                      ? 'border-emerald-500 bg-emerald-50 text-emerald-950 font-semibold ring-1 ring-emerald-500'
                                      : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                                  }`}
                                >
                                  <span
                                    className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[11px] shrink-0 ${
                                      opt.isCorrect ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600'
                                    }`}
                                  >
                                    {opt.label}
                                  </span>
                                  <span className="truncate flex-1">{opt.text}</span>
                                </button>
                              ))}
                            </div>
                          )}

                          {/* True/False Statements Editor */}
                          {q.questionType === 'true_false_multistatement' && q.trueFalseStatements && (
                            <div className="space-y-1.5 pt-1">
                              {q.trueFalseStatements.map((st) => (
                                <div
                                  key={st.subOrder}
                                  className="flex items-center justify-between p-2 rounded-lg border border-slate-200 bg-slate-50 text-xs"
                                >
                                  <div className="flex items-center space-x-2 flex-1 mr-2 truncate">
                                    <span className="font-bold text-slate-800">
                                      {st.subOrder})
                                    </span>
                                    <span className="truncate text-slate-700 text-[11px]">
                                      {st.statementText}
                                    </span>
                                  </div>
                                  <div className="flex items-center space-x-1 shrink-0">
                                    <button
                                      type="button"
                                      onClick={() => handleToggleTrueFalse(realIndex, st.subOrder, true)}
                                      className={`px-2 py-0.5 rounded text-[11px] font-bold cursor-pointer transition ${
                                        st.isCorrect
                                          ? 'bg-emerald-600 text-white'
                                          : 'bg-slate-200 text-slate-600 hover:bg-slate-300'
                                      }`}
                                    >
                                      Đúng
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => handleToggleTrueFalse(realIndex, st.subOrder, false)}
                                      className={`px-2 py-0.5 rounded text-[11px] font-bold cursor-pointer transition ${
                                        !st.isCorrect
                                          ? 'bg-rose-600 text-white'
                                          : 'bg-slate-200 text-slate-600 hover:bg-slate-300'
                                      }`}
                                    >
                                      Sai
                                    </button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {/* Confirmation Checkbox */}
                  <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl flex items-center justify-between">
                    <label className="flex items-center space-x-2.5 text-xs text-slate-800 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={isReviewedConfirmed}
                        onChange={(e) => setIsReviewedConfirmed(e.target.checked)}
                        className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500 cursor-pointer"
                      />
                      <span className="font-semibold">
                        Tôi đã kiểm tra kỹ toàn bộ nội dung câu hỏi và bảng đáp án số hóa
                      </span>
                    </label>

                    {isReviewedConfirmed && (
                      <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-md flex items-center space-x-1">
                        <Check className="w-3 h-3 text-emerald-600" />
                        <span>Đã xác nhận</span>
                      </span>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Footer Buttons */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-between">
            <div className="text-[11px] text-slate-500">
              {questionSource === 'upload_custom' && !isReviewedConfirmed && (
                <span className="text-amber-600 font-medium">
                  * Cần rà soát và xác nhận câu hỏi trước khi xuất bản
                </span>
              )}
            </div>

            <div className="flex items-center space-x-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 transition cursor-pointer"
              >
                Hủy bỏ
              </button>

              <button
                type="submit"
                disabled={isSubmitDisabled}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-400 text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer flex items-center space-x-1.5"
              >
                <PlusCircle className="w-4 h-4" />
                <span>
                  {questionSource === 'bank_shuffle'
                    ? 'Tạo và Xuất Bản Kỳ Thi'
                    : 'Xác Nhận Đề Đã Tải Lên & Xuất Bản'}
                </span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
