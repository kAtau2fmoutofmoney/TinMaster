import React, { useMemo, useState } from 'react';
import { ArrowLeft, ArrowRight, Brain, CheckCircle2, Clock3, Target, X } from 'lucide-react';
import { Question } from '../types';

export type DiagnosticPreferences = {
  targetScore: number;
  dailyMinutes: number;
  daysPerWeek: number;
  focus: 'score' | 'foundation' | 'coding' | 'network_web' | 'data_ai';
  goalNote: string;
  examDate?: string;
};

export type DiagnosticSubmission = {
  preferences: DiagnosticPreferences;
  questionIds: string[];
  answers: Record<string, string>;
};

interface Props {
  isOpen: boolean;
  questions: Question[];
  initialPreferences?: Partial<DiagnosticPreferences>;
  onClose: () => void;
  onSubmit: (submission: DiagnosticSubmission) => void;
}

const FOCUS_OPTIONS = [
  { value: 'score', label: 'Tăng điểm thi', desc: 'Ưu tiên những phần giúp kéo điểm lên nhanh và bám ma trận.' },
  { value: 'foundation', label: 'Củng cố nền tảng', desc: 'Học từ lỗ hổng kiến thức, đi từ dễ đến khó.' },
  { value: 'coding', label: 'Lập trình & thuật toán', desc: 'Python, thuật toán, cấu trúc dữ liệu và tư duy giải bài.' },
  { value: 'network_web', label: 'Mạng & Web', desc: 'Mạng máy tính, Internet, HTML/CSS và ứng dụng.' },
  { value: 'data_ai', label: 'CSDL & AI', desc: 'SQL, cơ sở dữ liệu, AI và các chủ đề dữ liệu.' },
] as const;

export const DiagnosticAssessmentModal: React.FC<Props> = ({ isOpen, questions, initialPreferences, onClose, onSubmit }) => {
  const [step, setStep] = useState(0);
  const [prefs, setPrefs] = useState<DiagnosticPreferences>({
    targetScore: initialPreferences?.targetScore ?? 0,
    dailyMinutes: initialPreferences?.dailyMinutes ?? 30,
    daysPerWeek: initialPreferences?.daysPerWeek ?? 6,
    focus: initialPreferences?.focus ?? 'score',
    goalNote: initialPreferences?.goalNote ?? '',
    examDate: initialPreferences?.examDate ?? '',
  });
  const [answers, setAnswers] = useState<Record<string, string>>({});

  const diagnosticQuestions = useMemo(() => {
    const single = questions.filter((q) => q.questionType === 'single_choice' && q.singleChoiceOptions?.length);
    const picked: Question[] = [];
    const concepts = Array.from(new Set(single.map((q) => q.conceptId)));
    for (const conceptId of concepts) {
      const q = single.find((item) => item.conceptId === conceptId);
      if (q) picked.push(q);
      if (picked.length >= 12) break;
    }
    if (picked.length < 12) {
      for (const q of single) {
        if (!picked.some((item) => item.id === q.id)) picked.push(q);
        if (picked.length >= 12) break;
      }
    }
    return picked.slice(0, 12);
  }, [questions]);

  if (!isOpen) return null;

  const questionIndex = Math.max(0, step - 1);
  const currentQuestion = diagnosticQuestions[questionIndex];
  const answeredCount = Object.keys(answers).length;
  const canContinue = step === 0 || (currentQuestion ? Boolean(answers[currentQuestion.id]) : false);

  const submit = () => {
    if (diagnosticQuestions.length === 0) return;
    if (Object.keys(answers).length !== diagnosticQuestions.length) return;
    onSubmit({ preferences: prefs, questionIds: diagnosticQuestions.map((q) => q.id), answers });
    setStep(0);
    setAnswers({});
  };

  const close = () => {
    setStep(0);
    setAnswers({});
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[100] bg-slate-950/45 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-3xl max-h-[92vh] overflow-y-auto bg-white rounded-2xl shadow-2xl border border-slate-200">
        <div className="sticky top-0 z-10 bg-white border-b border-slate-200 px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[11px] uppercase tracking-wider font-bold text-blue-600">AI Adaptive Planner</div>
              <h2 className="font-bold text-slate-900">Bài đánh giá đầu vào & thiết kế lộ trình</h2>
            </div>
          </div>
          <button onClick={close} className="p-2 rounded-lg hover:bg-slate-100 cursor-pointer"><X className="w-5 h-5" /></button>
        </div>

        <div className="p-5 sm:p-7">
          {step === 0 && (
            <div className="space-y-6">
              <div className="rounded-xl bg-blue-50 border border-blue-100 p-4 text-sm text-blue-900">
                Hệ thống sẽ dùng <b>mục tiêu + thời gian học + mong muốn + 12 câu chẩn đoán</b> để xác định điểm yếu và tạo lịch học từng ngày. Bài đánh giá này không được tính như một buổi luyện tập thông thường.
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-800">Mục tiêu điểm THPT <span className="text-red-500">*</span></label>
                <div className="mt-2 flex items-center gap-3">
                  <input type="range" min="5" max="10" step="0.1" value={prefs.targetScore >= 5 ? prefs.targetScore : 5} onChange={(e) => setPrefs({ ...prefs, targetScore: Number(e.target.value) })} className="w-full" />
                  <span className="font-mono font-bold text-lg w-14 text-right">{prefs.targetScore >= 5 ? prefs.targetScore.toFixed(1) : 'Chưa đặt'}</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">Kéo thanh điểm để xác nhận mục tiêu của bạn. AI sẽ không tự đặt mục tiêu nếu bạn chưa chọn.</p>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-semibold text-slate-800">Thời gian mỗi ngày</label>
                  <select value={prefs.dailyMinutes} onChange={(e) => setPrefs({ ...prefs, dailyMinutes: Number(e.target.value) })} className="mt-2 w-full rounded-lg border border-slate-300 px-3 py-2.5 bg-white">
                    {[20, 30, 45, 60, 90].map((m) => <option key={m} value={m}>{m} phút</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-sm font-semibold text-slate-800">Số ngày học / tuần</label>
                  <select value={prefs.daysPerWeek} onChange={(e) => setPrefs({ ...prefs, daysPerWeek: Number(e.target.value) })} className="mt-2 w-full rounded-lg border border-slate-300 px-3 py-2.5 bg-white">
                    {[3, 4, 5, 6, 7].map((d) => <option key={d} value={d}>{d} ngày</option>)}
                  </select>
                </div>
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-800">Bạn muốn ưu tiên điều gì?</label>
                <div className="mt-2 grid sm:grid-cols-2 gap-2">
                  {FOCUS_OPTIONS.map((item) => (
                    <button key={item.value} type="button" onClick={() => setPrefs({ ...prefs, focus: item.value })} className={`text-left rounded-xl border p-3 cursor-pointer transition ${prefs.focus === item.value ? 'border-blue-500 bg-blue-50 ring-1 ring-blue-200' : 'border-slate-200 hover:border-slate-300'}`}>
                      <div className="font-semibold text-sm text-slate-900">{item.label}</div>
                      <div className="text-xs text-slate-500 mt-1">{item.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-semibold text-slate-800">Ngày thi dự kiến <span className="font-normal text-slate-400">(tuỳ chọn)</span></label>
                  <input type="date" value={prefs.examDate ?? ''} onChange={(e) => setPrefs({ ...prefs, examDate: e.target.value })} className="mt-2 w-full rounded-lg border border-slate-300 px-3 py-2.5" />
                </div>
                <div>
                  <label className="text-sm font-semibold text-slate-800">Mong muốn của bạn</label>
                  <textarea value={prefs.goalNote} onChange={(e) => setPrefs({ ...prefs, goalNote: e.target.value })} placeholder="Ví dụ: Em yếu SQL, muốn tăng điểm nhanh và có thể học 30 phút/ngày..." className="mt-2 w-full min-h-[86px] rounded-lg border border-slate-300 px-3 py-2.5 resize-y" />
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button disabled={prefs.targetScore < 5} onClick={() => setStep(1)} className="btn px-5 py-2.5 cursor-pointer disabled:opacity-40">Bắt đầu 12 câu <ArrowRight className="w-4 h-4" /></button>
              </div>
            </div>
          )}

          {step > 0 && currentQuestion && (
            <div className="space-y-5">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span>Câu {step}/ {diagnosticQuestions.length}</span>
                <span>{answeredCount}/{diagnosticQuestions.length} đã trả lời</span>
              </div>
              <div className="h-2 bg-slate-100 rounded-full overflow-hidden"><div className="h-full bg-blue-600 transition-all" style={{ width: `${(step / diagnosticQuestions.length) * 100}%` }} /></div>

              <div className="rounded-xl border border-slate-200 p-5">
                <div className="flex items-center gap-2 text-xs text-slate-500 mb-3"><Target className="w-3.5 h-3.5" /> {currentQuestion.topicId} · {currentQuestion.difficulty === 'easy' ? 'Dễ' : currentQuestion.difficulty === 'medium' ? 'Vừa' : 'Khó'}</div>
                <h3 className="text-base sm:text-lg font-semibold leading-relaxed text-slate-900">{currentQuestion.stem}</h3>
                {currentQuestion.codeSnippet && <pre className="mt-4 bg-slate-950 text-slate-100 rounded-lg p-3 text-xs overflow-x-auto">{currentQuestion.codeSnippet.code}</pre>}
                <div className="mt-5 grid gap-2">
                  {currentQuestion.singleChoiceOptions?.map((option) => {
                    const selected = answers[currentQuestion.id] === option.label;
                    return <button key={option.label} type="button" onClick={() => setAnswers((prev) => ({ ...prev, [currentQuestion.id]: option.label }))} className={`text-left p-3 rounded-lg border flex gap-3 cursor-pointer transition ${selected ? 'border-blue-500 bg-blue-50' : 'border-slate-200 hover:bg-slate-50'}`}><span className={`w-7 h-7 shrink-0 rounded-full border flex items-center justify-center text-xs font-bold ${selected ? 'bg-blue-600 text-white border-blue-600' : 'text-slate-500'}`}>{option.label}</span><span className="text-sm text-slate-800">{option.text}</span></button>;
                  })}
                </div>
              </div>

              <div className="flex items-center justify-between pt-1">
                <button disabled={step === 1} onClick={() => setStep((s) => s - 1)} className="btn-secondary px-4 py-2 cursor-pointer disabled:opacity-40"><ArrowLeft className="w-4 h-4" /> Quay lại</button>
                {step < diagnosticQuestions.length ? <button disabled={!canContinue} onClick={() => setStep((s) => s + 1)} className="btn px-5 py-2 cursor-pointer disabled:opacity-40">Câu tiếp <ArrowRight className="w-4 h-4" /></button> : <button disabled={!canContinue || answeredCount !== diagnosticQuestions.length} onClick={submit} className="btn px-5 py-2 cursor-pointer disabled:opacity-40"><CheckCircle2 className="w-4 h-4" /> Tạo lộ trình AI</button>}
              </div>
              <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-400"><Clock3 className="w-3.5 h-3.5" /> Khoảng 8–10 phút · không tính vào số câu luyện tập</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
