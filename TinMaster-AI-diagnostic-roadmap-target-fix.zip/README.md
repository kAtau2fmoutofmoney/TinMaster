TinMaster – Hệ thống luyện thi Tin học THPT thích ứng

TinMaster là dự án Khoa học Kỹ thuật hướng đến việc xây dựng nền tảng ôn luyện thông minh cho học sinh THPT. Dự án ứng dụng trí tuệ nhân tạo (AI) để phân tích năng lực học tập, cá nhân hóa lộ trình ôn luyện và hỗ trợ học sinh chuẩn bị hiệu quả cho kỳ thi tốt nghiệp THPT môn Tin học.


## Chế độ chạy local không cần Supabase

Nếu chưa tạo file `.env` hoặc chưa có `VITE_SUPABASE_URL` và `VITE_SUPABASE_ANON_KEY`, TinMaster tự động chạy ở **Local Demo Mode** để bạn có thể test giao diện, đăng ký/đăng nhập và Progress ngay trên máy.

- Tài khoản local được lưu trong trình duyệt.
- Mỗi tài khoản có `userId` riêng.
- Progress, XP, số câu đã làm và lịch sử thi được lưu theo `userId`, không dùng chung giữa các tài khoản.
- Khi có cấu hình Supabase thật, app sẽ tự chuyển sang Supabase Auth.
- Local Demo Mode chỉ dành cho phát triển/test, không thay thế hệ thống xác thực production.

### Chạy local

```bash
npm install
npm run dev
```

Mở địa chỉ Vite hiển thị trong Terminal (thường là `http://localhost:3000`).
