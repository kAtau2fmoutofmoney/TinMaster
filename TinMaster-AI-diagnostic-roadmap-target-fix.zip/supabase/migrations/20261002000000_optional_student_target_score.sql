-- Student goals are optional until the student explicitly sets one.
alter table public.profiles
  alter column target_score drop default,
  alter column target_score drop not null;
